import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { readFile, readdir } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const release = JSON.parse(await readFile(new URL("clone/release.json", root), "utf8"));
const candidates = [
  ...release.managedFiles,
  "app/page.tsx",
  "clone/listing-description.md",
  "clone/CLONE_SAFETY.md",
];
const files = candidates.filter((file) => existsSync(new URL(file, root)));

const forbidden = [
  { name: "fixed ClawChat user ID", pattern: /usr_[0-9A-HJKMNP-TV-Z]{26}/g },
  { name: "creator Liveware app ID", pattern: /app-1bdb629a56d0a285/g },
  { name: "creator home path", pattern: /\/Users\/newbasedanny(?:\/|\b)/g },
  { name: "SSH forwarding host", pattern: /forward\.agent-dashboard\.clawling\.io/g },
  { name: "private key material", pattern: /-----BEGIN (?:OPENSSH|RSA|EC|PRIVATE) PRIVATE KEY-----/g },
  { name: "literal bearer token", pattern: /Authorization\s*:\s*Bearer\s+[A-Za-z0-9._~-]{16,}/gi },
];

for (const file of files) {
  const source = await readFile(new URL(file, root), "utf8");
  for (const rule of forbidden) {
    assert.doesNotMatch(source, rule.pattern, `${file} contains ${rule.name}`);
  }
}

if (existsSync(new URL("app/page.tsx", root))) {
  const page = await readFile(new URL("app/page.tsx", root), "utf8");
  assert.match(page, /URLSearchParams\(window\.location\.search\)\.get\("agent"\)/, "Liveware must receive the current clone identity at runtime");
  assert.match(page, /CLAWCHAT_USER_ID_PATTERN\.test/, "runtime Agent IDs must be validated");
  assert.match(page, /if \(!agentUserId\) return null/, "sharing must fail closed when no Agent identity is present");
} else {
  const staticRoot = new URL("runtime-static/", root);
  assert.ok(existsSync(new URL("index.html", staticRoot)), "clone runtime must contain a static Liveware entry page");
  const assetNames = await readdir(new URL("assets/", staticRoot));
  const pageAsset = assetNames.find((name) => /^page-.*\.js$/.test(name));
  assert.ok(pageAsset, "clone runtime must contain the interactive test bundle");
  const bundle = await readFile(new URL(`assets/${pageAsset}`, staticRoot), "utf8");
  assert.match(bundle, /URLSearchParams/, "static Liveware must read runtime query parameters");
  assert.match(bundle, /get\(`agent`\)/, "static Liveware must receive the current clone identity");
}

const registrar = await readFile(new URL("ops/wanxiang_liveware_register.py", root), "utf8");
assert.match(registrar, /fields\.get\("instanceId"\) != agent_id/, "startup registration must reject another Agent's Liveware");
assert.match(registrar, /\/opt\/data\/wanxiang-runtime\/site/, "Liveware code must use the clone-persistent runtime path");
assert.match(registrar, /tools\.register_app\(APP_NAME, app_id, url\)/, "startup registration must refresh the current Agent's app card");
assert.match(registrar, /"bind-static"/, "clones must serve the packaged static Liveware without workspace dependencies");

const hook = await readFile(new URL("clone/runtime-hooks/wanxiang-bootstrap/handler.py", root), "utf8");
assert.match(hook, /--send-activation/, "the pre-connect hook must deliver the deterministic clone-owner welcome");
assert.match(hook, /wanxiang_friend_greeting_daemon\.py/, "the pre-connect hook must preserve automatic friend greetings");

console.log(`Clone safety verified across ${files.length} public files.`);
