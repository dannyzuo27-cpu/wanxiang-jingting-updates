#!/usr/bin/env python3
"""Register this instance's Wanxiang Liveware on every container start.

The hook is intentionally model-free.  It rejects registrations inherited
from another Agent, reuses an app only when ``liveware app inspect`` proves
that the app belongs to the current Agent instance, and persists only the
current instance's public registration tuple.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from types import SimpleNamespace
from typing import Any

APP_NAME = "万象镜厅"
LEGACY_APP_NAMES = {"万象镜厅", "十四面镜"}
SOURCE_ROOT = Path(os.environ.get("WANXIANG_ROOT", Path(__file__).resolve().parents[1]))
RUNTIME_ROOT = Path("/opt/data/wanxiang-runtime/site")
ROOT = RUNTIME_ROOT if RUNTIME_ROOT.joinpath("runtime-static/index.html").is_file() else SOURCE_ROOT
CONFIG = Path("/opt/data/config.yaml")
STATE = Path("/opt/data/wanxiang-liveware/registration.json")
BRAND_SPEC = ROOT / "clone/brand-profile.json"
BRAND_STATE = Path("/opt/data/wanxiang-brand/profile.json")
LIVEWARE = Path("/opt/clawnest/bin/liveware")
PLUGIN = Path("/opt/data/plugins/clawchat")
DEFAULT_PORT = 3100
APP_ID_RE = re.compile(r"^app-[a-z0-9]+$")
USER_ID_RE = re.compile(r"^usr_[0-9A-HJKMNP-TV-Z]{26}$")
AGENT_ID_RE = re.compile(r"^agt_[0-9A-HJKMNP-TV-Z]{26}$")
URL_RE = re.compile(r"^https://(app-[a-z0-9]+)\.apps\.clawling\.io/?$")


def install_clone_runtime(source_root: Path = SOURCE_ROOT) -> Path:
    """Install the complete clone payload in Hermes' persistent data tree."""
    if source_root.resolve() != RUNTIME_ROOT.resolve():
        for relative in ("ops", "clone", "liveware", "scripts"):
            source = source_root / relative
            if source.is_dir():
                shutil.copytree(source, RUNTIME_ROOT / relative, dirs_exist_ok=True)
        for relative in ("public/agent-avatar.png", "public/wanxiang-release.json"):
            source = source_root / relative
            if source.is_file():
                target = RUNTIME_ROOT / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)

    packaged_static = RUNTIME_ROOT / "clone/runtime-static"
    if source_root.resolve() != RUNTIME_ROOT.resolve():
        packaged_static = source_root / "clone/runtime-static"
    if packaged_static.is_dir():
        shutil.copytree(packaged_static, RUNTIME_ROOT / "runtime-static", dirs_exist_ok=True)

    hook_source = RUNTIME_ROOT / "clone/runtime-hooks/wanxiang-bootstrap"
    hook_target = Path("/opt/data/hooks/wanxiang-bootstrap")
    if hook_source.is_dir():
        shutil.copytree(hook_source, hook_target, dirs_exist_ok=True)

    plugin_source = RUNTIME_ROOT / "clone/runtime-plugins/wanxiang-bootstrap"
    plugin_target = Path("/opt/data/.hermes/plugins/wanxiang-bootstrap")
    if plugin_source.is_dir():
        shutil.copytree(plugin_source, plugin_target, dirs_exist_ok=True)
        ensure_bootstrap_plugin_enabled()

    soul = RUNTIME_ROOT / "liveware/SOUL.md"
    skill = RUNTIME_ROOT / "liveware/skills/wanxiang-jingting/SKILL.md"
    greeting = RUNTIME_ROOT / "liveware/greeting.md"
    if soul.is_file():
        shutil.copy2(soul, "/opt/data/SOUL.md")
    if skill.is_file():
        Path("/opt/data/skills/wanxiang-jingting").mkdir(parents=True, exist_ok=True)
        shutil.copy2(skill, "/opt/data/skills/wanxiang-jingting/SKILL.md")
    if greeting.is_file():
        Path("/opt/data/clawchat").mkdir(parents=True, exist_ok=True)
        shutil.copy2(greeting, "/opt/data/clawchat/greeting.md")
    return RUNTIME_ROOT


def ensure_bootstrap_plugin_enabled(config_path: Path = CONFIG) -> None:
    """Enable the clone-preserved startup plugin without changing identities."""
    import yaml

    data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    plugins = data.setdefault("plugins", {})
    enabled = plugins.setdefault("enabled", [])
    if not isinstance(enabled, list):
        enabled = []
        plugins["enabled"] = enabled
    if "wanxiang-bootstrap" in enabled:
        return
    enabled.append("wanxiang-bootstrap")
    temporary = config_path.with_suffix(".wanxiang.tmp")
    temporary.write_text(
        yaml.safe_dump(data, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    os.chmod(temporary, config_path.stat().st_mode & 0o777)
    temporary.replace(config_path)


def run_liveware(*args: str, timeout: int = 30) -> str:
    result = subprocess.run(
        [str(LIVEWARE), *args],
        check=True,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return result.stdout


def parse_fields(output: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    for raw in output.splitlines():
        line = raw.strip()
        if not line:
            continue
        parts = line.split(None, 1)
        if len(parts) == 2:
            fields[parts[0]] = parts[1].strip()
    return fields


def load_identity(config_path: Path = CONFIG) -> tuple[str, str]:
    import yaml

    data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    extra = (((data.get("platforms") or {}).get("clawchat") or {}).get("extra") or {})
    agent_id = str(extra.get("agent_id") or "")
    user_id = str(extra.get("user_id") or "")
    if not AGENT_ID_RE.fullmatch(agent_id) or not USER_ID_RE.fullmatch(user_id):
        raise RuntimeError("current ClawChat Agent identity is unavailable")
    return agent_id, user_id


def app_url(app_id: str) -> str:
    if not APP_ID_RE.fullmatch(app_id):
        raise RuntimeError("invalid Liveware app id")
    return f"https://{app_id}.apps.clawling.io"


def inspect_owned_app(app_id: str, agent_id: str) -> dict[str, str] | None:
    if not APP_ID_RE.fullmatch(app_id):
        return None
    try:
        fields = parse_fields(run_liveware("app", "inspect", app_id))
    except (OSError, subprocess.SubprocessError):
        return None
    if fields.get("appId") != app_id or fields.get("instanceId") != agent_id:
        return None
    if fields.get("name") not in LEGACY_APP_NAMES:
        return None
    return fields


def list_owned_apps(agent_id: str) -> list[dict[str, str]]:
    """Discover owned apps directly from Liveware, including unregistered ones."""
    try:
        output = run_liveware("app", "list")
    except (OSError, subprocess.SubprocessError):
        return []
    owned: list[dict[str, str]] = []
    for app_id in dict.fromkeys(re.findall(r"\bapp-[a-z0-9]+\b", output)):
        fields = inspect_owned_app(app_id, agent_id)
        if fields is not None and fields.get("name") in LEGACY_APP_NAMES:
            owned.append(fields)
    return sorted(owned, key=lambda item: item.get("createdAt", ""))


def bind_static(app_id: str, static_root: Path, attempts: int = 5) -> None:
    """Bind the static payload with bounded retry, without minting a new app."""
    last_error: Exception | None = None
    for attempt in range(1, max(1, attempts) + 1):
        try:
            run_liveware("tunnel", "bind-static", app_id, str(static_root))
            return
        except (OSError, subprocess.SubprocessError) as exc:
            last_error = exc
            if attempt < attempts:
                time.sleep(min(8, attempt * 2))
    raise RuntimeError(f"static Liveware bind failed for {app_id}") from last_error


def load_matching_state(agent_id: str, user_id: str, state_path: Path = STATE) -> dict[str, Any] | None:
    try:
        data = json.loads(state_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if data.get("agent_id") != agent_id or data.get("agent_user_id") != user_id:
        return None
    app_id = str(data.get("app_id") or "")
    url = str(data.get("url") or "")
    match = URL_RE.fullmatch(url)
    if not match or match.group(1) != app_id or inspect_owned_app(app_id, agent_id) is None:
        return None
    return data


def save_state(data: dict[str, Any], state_path: Path = STATE) -> None:
    state_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(state_path.parent, 0o700)
    temporary = state_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    temporary.replace(state_path)


def load_brand_spec(spec_path: Path = BRAND_SPEC) -> dict[str, Any]:
    data = json.loads(spec_path.read_text(encoding="utf-8"))
    nickname = str(data.get("nickname") or "").strip()
    relative_avatar = str(data.get("avatarPath") or "")
    avatar = (ROOT / relative_avatar).resolve()
    if not nickname or not avatar.is_relative_to(ROOT.resolve()) or not avatar.is_file():
        raise RuntimeError("brand profile is incomplete")
    digest = hashlib.sha256(avatar.read_bytes()).hexdigest()
    return {
        "brandVersion": int(data.get("brandVersion") or 1),
        "nickname": nickname,
        "avatar": avatar,
        "avatar_sha256": digest,
    }


def brand_is_current(agent_user_id: str, spec: dict[str, Any], state_path: Path = BRAND_STATE) -> bool:
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return (
        state.get("agent_user_id") == agent_user_id
        and state.get("brandVersion") == spec["brandVersion"]
        and state.get("nickname") == spec["nickname"]
        and state.get("avatar_sha256") == spec["avatar_sha256"]
        and isinstance(state.get("avatar_url"), str)
        and state.get("avatar_url", "").startswith("https://")
    )


async def sync_brand_profile(tools: Any, agent_user_id: str) -> None:
    spec = load_brand_spec()
    if brand_is_current(agent_user_id, spec):
        return
    uploaded = await tools.upload_avatar_image(str(spec["avatar"]))
    avatar_url = str(uploaded.get("url") or "") if isinstance(uploaded, dict) else ""
    if not avatar_url.startswith("https://"):
        raise RuntimeError("Agent avatar upload failed")
    updated = await tools.update_account_profile(
        nickname=spec["nickname"],
        avatar_url=avatar_url,
    )
    if isinstance(updated, dict) and (updated.get("ok") is False or updated.get("error")):
        raise RuntimeError("Agent brand profile update failed")
    save_state(
        {
            "schemaVersion": 1,
            "agent_user_id": agent_user_id,
            "brandVersion": spec["brandVersion"],
            "nickname": spec["nickname"],
            "avatar_sha256": spec["avatar_sha256"],
            "avatar_url": avatar_url,
        },
        BRAND_STATE,
    )


async def clawchat_tools() -> Any:
    sys.path.insert(0, str(PLUGIN))
    from clawchat_gateway import tools

    return tools


async def register_once(port: int = DEFAULT_PORT) -> dict[str, Any]:
    runtime = install_clone_runtime()
    static_root = runtime / "runtime-static"
    if not static_root.joinpath("index.html").is_file() or not LIVEWARE.is_file():
        raise RuntimeError("fixed Wanxiang Liveware installation is incomplete")
    agent_id, user_id = load_identity()
    try:
        inherited = json.loads(STATE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        inherited = {}
    if inherited.get("agent_id") == agent_id and inherited.get("agent_user_id") == user_id:
        marker = RUNTIME_ROOT / "state/migrate-legacy-for-agent"
        marker.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        marker.write_text(agent_id + "\n", encoding="utf-8")
        os.chmod(marker, 0o600)
    tools = await clawchat_tools()
    await sync_brand_profile(tools, user_id)
    login = await tools.liveware_login()
    if isinstance(login, dict) and login.get("ok") is False:
        raise RuntimeError(str(login.get("error") or "Liveware login failed"))

    registered = await tools.list_apps()
    apps = registered.get("apps") if isinstance(registered, dict) else []
    apps = apps if isinstance(apps, list) else []
    state = load_matching_state(agent_id, user_id)
    app_id = str(state.get("app_id")) if state else ""

    if not app_id:
        for item in apps:
            if not isinstance(item, dict) or item.get("name") not in LEGACY_APP_NAMES:
                continue
            candidate = str(item.get("app_id") or "")
            if inspect_owned_app(candidate, agent_id) is not None:
                app_id = candidate
                break

    if not app_id:
        owned = list_owned_apps(agent_id)
        if owned:
            app_id = str(owned[0].get("appId") or "")

    if not app_id:
        created = parse_fields(run_liveware("app", "create", APP_NAME, "--agent-type", "hermes"))
        app_id = str(created.get("appId") or "")
        if inspect_owned_app(app_id, agent_id) is None:
            raise RuntimeError("new Liveware app is not bound to the current Agent instance")

    url = app_url(app_id)
    bind_static(app_id, static_root)
    await tools.register_app(APP_NAME, app_id, url)

    for item in apps:
        if not isinstance(item, dict) or item.get("name") not in LEGACY_APP_NAMES:
            continue
        stale = str(item.get("app_id") or "")
        if stale and stale != app_id:
            await tools.unregister_app(stale)

    state = {
        "schemaVersion": 1,
        "agent_id": agent_id,
        "agent_user_id": user_id,
        "app_id": app_id,
        "app_name": APP_NAME,
        "url": url,
        "port": port,
    }
    save_state(state)
    return state


async def send_activation_welcome(state: dict[str, Any]) -> bool:
    """Deterministically deliver the clone owner's one-time first greeting."""
    sys.path.insert(0, str(PLUGIN))
    sys.path.insert(0, str(RUNTIME_ROOT))
    from clawchat_gateway.standalone_send import standalone_send
    from clawchat_gateway.storage import get_clawchat_store
    from liveware.wanxiang_auto_greeting import GREETING_TEXT, liveware_url_for_agent

    store = get_clawchat_store()
    claim = store.claim_pending_activation_bootstrap(platform="hermes", account_id="default")
    if claim is None:
        return False
    conversation_id = str(getattr(claim, "conversation_id", "") or "")
    claimed_at = getattr(claim, "claimed_at", None)
    if not conversation_id:
        return False
    url = liveware_url_for_agent(state["agent_user_id"], state["url"])
    message = GREETING_TEXT.format(url=url)
    result = await standalone_send(SimpleNamespace(extra={}), conversation_id, message)
    if not isinstance(result, dict) or result.get("success") is not True:
        if claimed_at is not None:
            store.release_activation_bootstrap_claim(
                platform="hermes",
                account_id="default",
                conversation_id=conversation_id,
                claimed_at=int(claimed_at),
            )
        raise RuntimeError(f"activation greeting failed: {result}")
    marked = store.mark_activation_bootstrap_sent(
        platform="hermes",
        account_id="default",
        conversation_id=conversation_id,
        claimed_at=claimed_at,
    )
    if not marked:
        raise RuntimeError("activation greeting sent but state was not committed")
    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--retry-seconds", type=int, default=15)
    parser.add_argument("--max-attempts", type=int, default=20)
    parser.add_argument("--send-activation", action="store_true")
    args = parser.parse_args()
    for attempt in range(1, max(1, args.max_attempts) + 1):
        try:
            state = asyncio.run(register_once(args.port))
            if args.send_activation:
                asyncio.run(send_activation_welcome(state))
            print(json.dumps({"status": "registered", "app_id": state["app_id"], "url": state["url"]}), flush=True)
            return 0
        except Exception as exc:
            print(f"registration attempt {attempt} failed: {exc}", file=sys.stderr, flush=True)
            if attempt < args.max_attempts:
                time.sleep(max(1, args.retry_seconds))
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
