"""Clone-preserved Hermes startup plugin for Wanxiang Jingting."""

from __future__ import annotations

import subprocess
from pathlib import Path

ROOT = Path("/opt/data/wanxiang-runtime/site")
PYTHON = "/opt/hermes/.venv/bin/python3"
LOG_DIR = Path("/opt/data/logs")


def _log(name: str):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    return (LOG_DIR / name).open("ab", buffering=0)


def _bootstrap() -> None:
    registrar = ROOT / "ops/wanxiang_liveware_register.py"
    if registrar.is_file():
        subprocess.run(
            [PYTHON, str(registrar), "--send-activation", "--max-attempts", "8", "--retry-seconds", "3"],
            cwd=ROOT,
            stdout=_log("wanxiang-clone-bootstrap.log"),
            stderr=subprocess.STDOUT,
            timeout=180,
            check=False,
        )

    for script, log in (
        ("wanxiang_friend_greeting_daemon.py", "wanxiang-friend-greeting.log"),
        ("wanxiang_updater.py", "wanxiang-updater.log"),
    ):
        path = ROOT / "ops" / script
        if not path.is_file():
            continue
        args = [PYTHON, str(path)]
        if script == "wanxiang_updater.py":
            args.append("--daemon")
        subprocess.Popen(
            args,
            cwd=ROOT,
            stdin=subprocess.DEVNULL,
            stdout=_log(log),
            stderr=subprocess.STDOUT,
            start_new_session=True,
            close_fds=True,
        )


_bootstrap()


def register(context) -> None:
    """Hermes plugin entry point; startup work is intentionally import-time."""
    del context
