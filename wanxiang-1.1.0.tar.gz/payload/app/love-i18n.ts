import type { Locale } from "./i18n";

export const LOVE_DIMENSIONS = ["closeness", "autonomy", "expression", "stability", "romance", "repair"] as const;
export type LoveDimension = (typeof LOVE_DIMENSIONS)[number];
export const LOVE_QUESTION_DIMENSIONS: LoveDimension[] = [
  "closeness", "autonomy", "expression", "stability", "romance", "repair",
  "closeness", "autonomy", "expression", "stability", "romance", "repair",
  "closeness", "autonomy", "expression", "stability", "romance", "repair",
];

export const LOVE_QUESTIONS: Record<Locale, string[]> = {
  "zh-CN": [
    "在意一个人时，我会自然地想保持稳定联系，并分享日常的小事。", "即使关系很亲密，我仍需要一些完全属于自己的时间和空间。", "喜欢、想念或感激一个人时，我通常愿意直接说出来。", "明确的承诺、边界和未来计划，会让我在关系里更安心。", "小小的仪式、惊喜和共同记忆，会明显提升我的心动感。", "发生矛盾后，我更愿意把问题讲清楚，并一起找到修复方式。",
    "对方突然疏远或迟迟不回应时，我会很想尽快重新建立连接。", "我认为好的恋爱不该挤压彼此的朋友、兴趣和个人目标。", "需要没有被满足时，我倾向于说清楚，而不是让对方猜。", "比起一时的热烈，我更容易被长期可靠和说到做到打动。", "我愿意主动安排约会、纪念日或有新鲜感的共同体验。", "争执暂时停下后，我通常能够回到话题，而不是让问题一直悬着。",
    "做重要决定时，我会希望听见伴侣的想法，也让对方参与其中。", "我能在关系中说“不”，也能接受对方有自己的“不”。", "面对嫉妒、不安或失落，我愿意描述自己的感受，而不是先指责。", "稳定而可预期的关心，比忽冷忽热的强烈刺激更适合我。", "关系进入平淡期时，我会想办法加入一点变化，让彼此重新有感觉。", "对我来说，有效的道歉还应包含：发生了什么，以及下次会怎么做。",
  ],
  "zh-TW": [
    "在意一個人時，我會自然地想保持穩定聯繫，並分享日常的小事。", "即使關係很親密，我仍需要一些完全屬於自己的時間和空間。", "喜歡、想念或感激一個人時，我通常願意直接說出來。", "明確的承諾、界線和未來計畫，會讓我在關係裡更安心。", "小小的儀式、驚喜和共同回憶，會明顯提升我的心動感。", "發生矛盾後，我更願意把問題說清楚，並一起找到修復方式。",
    "對方突然疏遠或遲遲不回應時，我會很想盡快重新建立連結。", "我認為好的戀愛不該擠壓彼此的朋友、興趣和個人目標。", "需要沒有被滿足時，我傾向於說清楚，而不是讓對方猜。", "比起一時的熱烈，我更容易被長期可靠和說到做到打動。", "我願意主動安排約會、紀念日或有新鮮感的共同體驗。", "爭執暫時停下後，我通常能夠回到話題，而不是讓問題一直懸著。",
    "做重要決定時，我會希望聽見伴侶的想法，也讓對方參與其中。", "我能在關係中說『不』，也能接受對方有自己的『不』。", "面對嫉妒、不安或失落，我願意描述自己的感受，而不是先指責。", "穩定而可預期的關心，比忽冷忽熱的強烈刺激更適合我。", "關係進入平淡期時，我會想辦法加入一點變化，讓彼此重新有感覺。", "對我來說，有效的道歉還應包含：發生了什麼，以及下次會怎麼做。",
  ],
  en: [
    "When I care about someone, I want steady contact and to share small parts of daily life.", "Even in a close relationship, I still need time and space that are entirely my own.", "When I like, miss, or appreciate someone, I am usually willing to say it directly.", "Clear commitments, boundaries, and future plans help me feel secure in a relationship.", "Small rituals, surprises, and shared memories noticeably deepen my romantic feelings.", "After conflict, I prefer to clarify what happened and find a way to repair it together.",
    "When someone suddenly feels distant or replies very late, I want to reconnect quickly.", "A good relationship should not squeeze out either person's friends, interests, or goals.", "When a need is not met, I prefer to name it instead of expecting the other person to guess.", "Long-term reliability and follow-through move me more than a burst of intensity.", "I like taking the initiative to plan dates, anniversaries, or fresh shared experiences.", "After a pause in an argument, I can return to the issue instead of leaving it unresolved.",
    "For important decisions, I want to hear my partner's view and include them in the process.", "I can say no in a relationship, and accept that the other person has their own no.", "With jealousy, insecurity, or disappointment, I describe my feelings before blaming.", "Steady, predictable care suits me better than intense hot-and-cold attention.", "When a relationship feels routine, I look for novelty to renew our connection.", "A useful apology includes what happened and what will change next time.",
  ],
  ja: [
    "大切な人とは安定して連絡を取り、日常の小さなことも共有したいです。", "親密な関係でも、自分だけの時間と空間が必要です。", "好き、会いたい、感謝している気持ちを言葉にできます。", "明確な約束、境界、将来の計画があると安心できます。", "小さな儀式や驚き、二人の思い出がときめきを大きくします。", "衝突の後は、何が起きたかを整理し、一緒に修復したいです。",
    "相手が急に遠ざかったり返信が遅いと、早くつながり直したくなります。", "良い恋愛は友人、興味、個人の目標を圧迫しないと思います。", "必要が満たされない時、察してもらうより言葉で伝えます。", "一時の激しさより、長く続く信頼と有言実行に心を動かされます。", "デート、記念日、新鮮な体験を自分から計画するのが好きです。", "口論を止めても、落ち着いた後で未解決の話に戻れます。",
    "大切な決断では、相手の考えを聞き、過程に参加してほしいです。", "関係の中で『嫌だ』と言え、相手の『嫌だ』も受け止められます。", "嫉妬や不安がある時、責める前に自分の感情を説明します。", "激しい駆け引きより、安定して予測できる気遣いが合っています。", "関係が単調になると、少し変化を加えてつながりを新しくします。", "有効な謝罪には、何が起きたかと次にどう変えるかが必要です。",
  ],
  es: [
    "Cuando alguien me importa, busco contacto estable y compartir pequeños momentos del día.", "Incluso en una relación íntima, necesito tiempo y espacio completamente propios.", "Cuando quiero, extraño o agradezco a alguien, suelo decirlo directamente.", "Los compromisos, límites y planes claros me hacen sentir seguridad.", "Los pequeños rituales, sorpresas y recuerdos aumentan mi ilusión romántica.", "Después de un conflicto, prefiero aclararlo y encontrar juntos una forma de reparar.",
    "Si la otra persona se distancia o tarda en responder, quiero reconectar pronto.", "Una buena relación no debería desplazar amistades, intereses ni metas personales.", "Si una necesidad no se cumple, prefiero expresarla en vez de esperar que la adivinen.", "La fiabilidad constante me conmueve más que una intensidad momentánea.", "Me gusta organizar citas, aniversarios o experiencias nuevas.", "Tras pausar una discusión, suelo volver al tema en vez de dejarlo sin resolver.",
    "En decisiones importantes, quiero escuchar e incluir a mi pareja.", "Puedo decir que no y aceptar que la otra persona también lo haga.", "Ante celos o inseguridad, explico lo que siento antes de culpar.", "Me conviene más un cuidado estable que una atención intensa e intermitente.", "Cuando la relación se vuelve rutinaria, busco algo nuevo que renueve la conexión.", "Una disculpa útil incluye qué ocurrió y qué cambiará la próxima vez.",
  ],
  ko: [
    "누군가를 소중히 여기면 꾸준히 연락하고 일상의 작은 일도 나누고 싶습니다.", "가까운 관계라도 온전히 나만의 시간과 공간이 필요합니다.", "좋아함, 그리움, 고마움을 느낄 때 직접 말할 수 있습니다.", "분명한 약속과 경계, 미래 계획이 관계에서 안정감을 줍니다.", "작은 의식과 놀라움, 함께 만든 추억이 설렘을 키웁니다.", "갈등 뒤에는 상황을 분명히 하고 함께 회복 방법을 찾고 싶습니다.",
    "상대가 멀어지거나 답장이 늦으면 빨리 다시 연결되고 싶습니다.", "좋은 연애는 서로의 친구, 관심사, 개인 목표를 밀어내지 않아야 합니다.", "욕구가 충족되지 않으면 알아맞히길 기다리기보다 직접 말합니다.", "순간의 강렬함보다 오래가는 신뢰와 약속을 지키는 태도에 감동합니다.", "데이트, 기념일, 새로운 경험을 먼저 계획하는 것을 좋아합니다.", "다툼을 멈춘 뒤에도 문제를 그대로 두지 않고 다시 이야기할 수 있습니다.",
    "중요한 결정을 할 때 상대의 생각을 듣고 함께하기를 바랍니다.", "관계에서 싫다고 말할 수 있고, 상대의 거절도 받아들입니다.", "질투나 불안이 생기면 비난하기 전에 내 감정을 설명합니다.", "뜨겁고 차가운 자극보다 꾸준하고 예측 가능한 관심이 잘 맞습니다.", "관계가 단조로워지면 작은 변화를 더해 연결감을 되살립니다.", "좋은 사과에는 무슨 일이 있었는지와 다음에 바꿀 점이 들어가야 합니다.",
  ],
};

export const LOVE_LABELS: Record<Locale, Record<LoveDimension, string>> = {
  "zh-CN":{closeness:"靠近",autonomy:"自主",expression:"表达",stability:"安定",romance:"浪漫",repair:"修复"}, "zh-TW":{closeness:"靠近",autonomy:"自主",expression:"表達",stability:"安定",romance:"浪漫",repair:"修復"}, en:{closeness:"Closeness",autonomy:"Autonomy",expression:"Expression",stability:"Stability",romance:"Romance",repair:"Repair"}, ja:{closeness:"親密",autonomy:"自律",expression:"表現",stability:"安定",romance:"ロマンス",repair:"修復"}, es:{closeness:"Cercanía",autonomy:"Autonomía",expression:"Expresión",stability:"Estabilidad",romance:"Romance",repair:"Reparación"}, ko:{closeness:"친밀",autonomy:"자율",expression:"표현",stability:"안정",romance:"낭만",repair:"회복"},
};

export const LOVE_GROWTH_LABELS: Record<Locale,string> = {
  "zh-CN":"相对低位", "zh-TW":"相對低位", en:"Lowest emphasis", ja:"相対的に低い領域", es:"Menor énfasis", ko:"상대적 저점",
};
export const LOVE_TIED_LABELS: Record<Locale,string> = {
  "zh-CN":"并列主导", "zh-TW":"並列主導", en:"Co-primary", ja:"同率の主傾向", es:"Tendencia principal compartida", ko:"공동 주도",
};

const CN_VERDICTS: Record<LoveDimension,string> = {
  closeness:"你想要的不是黏在一起，而是我找得到你，你也愿意把生活分给我一点。",
  autonomy:"你会爱人，但不会把自己交出去：好的关系应该亲密，也应该有呼吸。",
  expression:"你最受不了的不是分歧，是明明有话，却非要让彼此靠猜。",
  stability:"你要的不是轰轰烈烈，而是一个说到做到、遇到问题还愿意回来的人。",
  romance:"你不是恋爱脑，你只是相信爱需要被看见；没有表达的喜欢，很容易被日常淹没。",
  repair:"你不怕吵架，你怕的是吵完以后，没有人愿意回来把关系收拾好。",
};

const CN_SECONDARY: Record<LoveDimension,string> = {
  closeness:"你通常会用持续联系和分享日常，让这份需要落地。",
  autonomy:"你也很看重自己的空间，不喜欢用牺牲自我证明爱。",
  expression:"你更愿意把话说出来，不希望重要感受长期靠猜。",
  stability:"你会用可靠和兑现承诺，判断一段关系值不值得继续。",
  romance:"你需要一些仪式感，让喜欢不被平淡生活磨掉。",
  repair:"你很看重矛盾后的态度：愿不愿意回来谈，比谁先低头更重要。",
};

const CN_LOW_POINTS: Record<LoveDimension,string> = {
  closeness:"你并不是不在乎，只是不太会靠高频联系确认感情。对方如果需要很多回应，可能会误以为你在变冷。",
  autonomy:"你进入关系后容易把“我们”放得很前面，有时会忘记自己也需要独处、朋友和个人节奏。",
  expression:"你心里有感受，但不一定会立刻说。憋久了以后，对方可能只看到你的情绪，看不到真正的需要。",
  stability:"你更相信当下的感觉，不太喜欢过早谈承诺和计划；遇到需要确定性的人，容易让对方没底。",
  romance:"你不是不浪漫，只是不会把仪式感放在前面。你觉得“我一直都在”已经是爱，对方却可能还想看见表达。",
  repair:"你可能需要很久才能重新面对矛盾。暂停没有问题，但如果不说什么时候回来，对方容易把它理解成逃避。",
};

const CN_MATCH: Record<LoveDimension,string> = {
  closeness:"别让你一直猜。忙可以，但要说一声；需要空间可以，但也要告诉你什么时候会回来。",
  autonomy:"尊重你的节奏，不用查岗和牺牲证明爱。越信任你，你反而越愿意靠近。",
  expression:"把话说直，但别逼你当场给答案。真诚、具体、不过度试探，就是最有效的沟通。",
  stability:"少画大饼，多兑现小事。准时出现、说到做到，比突然的浪漫更能打动你。",
  romance:"别只说“你懂我的心”。偶尔认真安排一次约会、留下一段共同记忆，你会记很久。",
  repair:"争执可以暂停，但不能消失。先接住感受，再回来谈解决办法，你会慢慢放下防备。",
};

const CN_TAGS: Record<LoveDimension,string> = {
  closeness:"需要回应", autonomy:"亲密有边界", expression:"有话直说", stability:"长期主义", romance:"爱要被看见", repair:"吵完要回来",
};

export function loveVerdict(locale:Locale, primary:LoveDimension, secondary:LoveDimension, tied=false):string {
  const labels=LOVE_LABELS[locale];
  if (tied && locale === "zh-CN") return `${CN_VERDICTS[primary]}${CN_SECONDARY[secondary]}这两项得分相同，是你的双核心。`;
  if (tied && locale === "zh-TW") return `你的結果是「${labels[primary]} × ${labels[secondary]}」雙核心：兩種傾向得分相同，會共同主導你的戀愛方式。`;
  if (tied && locale === "ja") return `「${labels[primary]} × ${labels[secondary]}」が同率の二つの中心です。両方があなたの恋愛スタイルを形づくります。`;
  if (tied && locale === "es") return `${labels[primary]} y ${labels[secondary]} empatan como dos núcleos de tu manera de amar.`;
  if (tied && locale === "ko") return `‘${labels[primary]} × ${labels[secondary]}’이 같은 점수의 두 핵심이며 함께 연애 방식을 이끕니다.`;
  if (tied) return `${labels[primary]} and ${labels[secondary]} are tied as two co-primary drives in your way of loving.`;
  if (locale === "zh-CN") return `${CN_VERDICTS[primary]}${CN_SECONDARY[secondary]}`;
  if (locale === "zh-TW") return `你最鮮明的戀愛取向是「${labels[primary]}」，第二驅動力是「${labels[secondary]}」。這是你的相對排序，不是模糊的性格標籤。`;
  if (locale === "ja") return `あなたの最も強い恋愛傾向は「${labels[primary]}」、次は「${labels[secondary]}」です。これは曖昧な性格分類ではなく、回答内の相対順位です。`;
  if (locale === "es") return `Tu orientación más marcada es ${labels[primary]}; la segunda es ${labels[secondary]}. Es un orden relativo de tus respuestas, no una etiqueta ambigua.`;
  if (locale === "ko") return `가장 뚜렷한 연애 성향은 ‘${labels[primary]}’, 두 번째는 ‘${labels[secondary]}’입니다. 모호한 성격 꼬리표가 아니라 응답 안의 상대 순위입니다.`;
  return `Your clearest relationship orientation is ${labels[primary]}; ${labels[secondary]} is the supporting drive. This is a relative ranking within your answers, not a vague personality label.`;
}

export function loveLowPoint(locale:Locale, dimension:LoveDimension):string {
  if (locale === "zh-CN") return CN_LOW_POINTS[dimension];
  return `${LOVE_LABELS[locale][dimension]} received your lowest relative score. It is not a flaw; it is simply the part of a relationship you are least likely to prioritize automatically.`;
}

export function loveMatch(locale:Locale, primary:LoveDimension):string {
  if (locale === "zh-CN") return CN_MATCH[primary];
  return `The easiest way to connect with you is to notice and respect your need for ${LOVE_LABELS[locale][primary].toLowerCase()}.`;
}

export function loveTags(locale:Locale, primary:LoveDimension, secondary:LoveDimension, growth:LoveDimension):string[] {
  if (locale === "zh-CN") return [CN_TAGS[primary],CN_TAGS[secondary],`不太看重${LOVE_LABELS[locale][growth]}`];
  return [LOVE_LABELS[locale][primary],LOVE_LABELS[locale][secondary],`Low ${LOVE_LABELS[locale][growth]}`];
}

type LoveMessages = { chamber:string; title:string; subtitle:string; intro:string; enter:string; back:string; questionCount:string; duration:string; reportMeta:string; privacy:string; scaleLow:string; scaleMid:string; scaleHigh:string; choose:string; previous:string; exit:string; report:string; reportNote:string; primary:string; secondary:string; profile:string; strength:string; blindspot:string; action:string; shareTitle:string; shareBody:string; returnChat:string; draftHint:string; agentRequired:string; again:string; disclaimer:string; shareRequest:string };
export const LOVE_MESSAGES: Record<Locale, LoveMessages> = {
  "zh-CN":{chamber:"第二镜室 · 现已开放",title:"心动棱镜",subtitle:"恋爱人格测试",intro:"18个关系场景，观察你如何靠近、表达、保留自己，也如何在矛盾之后重新靠近。它不判断你会不会爱，只呈现你更习惯怎样去爱。",enter:"进入心室",back:"返回镜厅",questionCount:"18 道心问",duration:"约 3–4 分钟",reportMeta:"六维恋爱报告",privacy:"答案只在本次测试中临时保留，退出即清空。",scaleLow:"完全不像我",scaleMid:"一半像我",scaleHigh:"非常像我",choose:"选择最接近你的程度",previous:"上一题",exit:"退出测试",report:"你的恋爱人格",reportNote:"这是一张当下关系偏好的切面，不是依恋诊断，也不决定你与谁相配。",primary:"最看重",secondary:"第二需要",profile:"你的恋爱需求地图",strength:"你在恋爱里真正要什么",blindspot:"你最容易卡在哪里",action:"别人怎么和你相处",shareTitle:"把结果交给镜厅向导",shareBody:"只分享六维分数和人格摘要，不包含单题答案。向导会继续用人话解读，不给你贴标签。",returnChat:"把结果发给镜厅向导",draftHint:"点击后会返回与向导的对话，并把简短结果放进输入框；确认后发送即可。",agentRequired:"当前链接没有向导身份，无法安全判断该发给谁。请从 Agent 发来的镜厅卡片进入。",again:"再测一次",disclaimer:"仅供娱乐与自我观察，不构成心理诊断或关系建议。",shareRequest:"请直接用人话分析：先给一句适合分享的总结，再说我在恋爱里真正需要什么、最容易卡在哪里，以及别人怎样和我相处。不要堆心理学术语。"},
  "zh-TW":{chamber:"第二鏡室 · 現已開放",title:"心動稜鏡",subtitle:"戀愛人格測試",intro:"18個關係場景，觀察你如何靠近、表達、保留自己，也如何在矛盾之後重新靠近。它不判斷你會不會愛，只呈現你更習慣怎樣去愛。",enter:"進入心室",back:"返回鏡廳",questionCount:"18 道心問",duration:"約 3–4 分鐘",reportMeta:"六維戀愛報告",privacy:"答案只在本次測試中暫時保留，退出即清空。",scaleLow:"完全不像我",scaleMid:"一半像我",scaleHigh:"非常像我",choose:"選擇最接近你的程度",previous:"上一題",exit:"退出測試",report:"你的戀愛人格",reportNote:"這是當下關係偏好的一個切面，不是依戀診斷，也不決定你與誰相配。",primary:"主導人格",secondary:"第二傾向",profile:"六維關係光譜",strength:"你帶進關係的禮物",blindspot:"壓力下的盲點",action:"一個小行動",shareTitle:"讓鏡廳嚮導陪你讀懂這份結果",shareBody:"只分享六維分數和人格摘要，不包含單題答案，也不會與其他好友比較或存為長期記憶。",returnChat:"帶結果返回對話",draftHint:"結果會自動填入輸入框草稿，確認後傳送即可。",agentRequired:"請從 Agent 傳來的鏡廳卡片進入，才能把結果安全帶回目前對話。",again:"再測一次",disclaimer:"僅供娛樂與自我觀察，不構成心理診斷或關係建議。",shareRequest:"請用繁體中文給我一句話總結、一段簡短解讀和一個溫和可執行的關係建議。"},
  en:{chamber:"CHAMBER II · NOW OPEN",title:"The Heart Prism",subtitle:"Love Personality Test",intro:"Eighteen relationship moments reveal how you move closer, express affection, preserve your own space, and reconnect after tension. It does not judge how well you love—only the way you tend to love.",enter:"Enter the heart chamber",back:"Back to the hall",questionCount:"18 heart questions",duration:"About 3–4 minutes",reportMeta:"Six-dimension report",privacy:"Answers exist only during this test and are cleared when you leave.",scaleLow:"Not like me",scaleMid:"Somewhat like me",scaleHigh:"Very like me",choose:"Choose what feels closest to you",previous:"Previous",exit:"Exit test",report:"Your love personality",reportNote:"A snapshot of current preferences, not an attachment diagnosis or compatibility verdict.",primary:"Primary persona",secondary:"Secondary tendency",profile:"Six relationship dimensions",strength:"What you bring to love",blindspot:"Blind spot under stress",action:"One small action",shareTitle:"Let the guide help you read this result",shareBody:"Only the six scores and persona summary are shared—never individual answers, comparisons, or long-term memory.",returnChat:"Return to chat with result",draftHint:"The result will appear as a draft. Review it, then send.",agentRequired:"Open from the card sent by this Agent to return the result safely.",again:"Take it again",disclaimer:"For entertainment and self-reflection only. Not diagnosis or relationship advice.",shareRequest:"Give me a one-line summary, a brief reading, and one gentle practical relationship suggestion in English."},
  ja:{chamber:"第二鏡室 · 公開中",title:"心のプリズム",subtitle:"恋愛人格テスト",intro:"18の関係場面から、近づき方、愛情表現、自分の保ち方、衝突後のつながり直し方を見つめます。",enter:"心の鏡室へ",back:"鏡庁へ戻る",questionCount:"18の心の問い",duration:"約3〜4分",reportMeta:"6次元レポート",privacy:"回答はテスト中だけ一時保存され、退出すると消去されます。",scaleLow:"全く違う",scaleMid:"少し当てはまる",scaleHigh:"とても当てはまる",choose:"最も近い程度を選ぶ",previous:"前の問い",exit:"テストを終了",report:"あなたの恋愛人格",reportNote:"今の関係の好みを映す一場面で、診断や相性判定ではありません。",primary:"主な人格",secondary:"第二の傾向",profile:"6つの関係次元",strength:"恋に持ち込む力",blindspot:"ストレス時の盲点",action:"小さな一歩",shareTitle:"案内人と一緒に結果を読み解く",shareBody:"6次元の得点と要約だけを共有し、個別回答や長期記憶は含みません。",returnChat:"結果を持ってチャットへ",draftHint:"結果が下書きに入ります。確認して送信してください。",agentRequired:"Agentから届いたカードから開くと安全に戻せます。",again:"もう一度",disclaimer:"娯楽と自己観察用です。心理診断や関係助言ではありません。",shareRequest:"日本語で一文の要約、短い解説、実行できる穏やかな提案を一つください。"},
  es:{chamber:"SALA II · YA ABIERTA",title:"El prisma del corazón",subtitle:"Test de personalidad amorosa",intro:"Dieciocho escenas muestran cómo te acercas, expresas afecto, conservas tu espacio y vuelves a conectar.",enter:"Entrar",back:"Volver al salón",questionCount:"18 preguntas",duration:"Unos 3–4 minutos",reportMeta:"Informe de seis dimensiones",privacy:"Las respuestas se borran al salir.",scaleLow:"Nada como yo",scaleMid:"Algo como yo",scaleHigh:"Muy como yo",choose:"Elige el grado más cercano",previous:"Anterior",exit:"Salir",report:"Tu personalidad amorosa",reportNote:"Una instantánea, no un diagnóstico ni un veredicto de compatibilidad.",primary:"Personalidad principal",secondary:"Segunda tendencia",profile:"Seis dimensiones",strength:"Lo que aportas al amor",blindspot:"Punto ciego bajo presión",action:"Una pequeña acción",shareTitle:"Deja que el guía te ayude a leer el resultado",shareBody:"Solo se comparten las puntuaciones y el resumen, nunca respuestas individuales ni memoria.",returnChat:"Volver al chat",draftHint:"El resultado aparecerá como borrador. Revísalo y envíalo.",agentRequired:"Abre la tarjeta enviada por este Agent para devolver el resultado.",again:"Repetir",disclaimer:"Solo para entretenimiento y reflexión. No es diagnóstico ni consejo.",shareRequest:"Dame una frase de resumen, una lectura breve y una sugerencia amable y práctica en español."},
  ko:{chamber:"두 번째 거울방 · 공개 중",title:"마음 프리즘",subtitle:"연애 성격 테스트",intro:"18가지 관계 장면으로 가까워짐, 표현, 나만의 공간, 갈등 뒤 연결 방식을 비춰 봅니다.",enter:"마음의 방 들어가기",back:"거울 홀로",questionCount:"18개 질문",duration:"약 3–4분",reportMeta:"6차원 보고서",privacy:"답변은 나가면 삭제됩니다.",scaleLow:"전혀 나 같지 않다",scaleMid:"어느 정도 나 같다",scaleHigh:"매우 나 같다",choose:"가장 가까운 정도를 고르세요",previous:"이전",exit:"나가기",report:"나의 연애 성격",reportNote:"현재 선호의 한 장면일 뿐, 진단이나 궁합 판정이 아닙니다.",primary:"주도 성격",secondary:"두 번째 경향",profile:"6가지 관계 차원",strength:"사랑에 가져오는 힘",blindspot:"압박 속 사각지대",action:"작은 행동 하나",shareTitle:"안내자와 함께 결과를 읽어 보세요",shareBody:"점수와 요약만 공유하며, 개별 답변이나 장기 기억은 포함하지 않습니다.",returnChat:"결과와 함께 대화로",draftHint:"결과가 초안으로 들어갑니다. 확인 후 보내세요.",agentRequired:"Agent가 보낸 카드에서 열어야 안전하게 돌아갈 수 있습니다.",again:"다시 하기",disclaimer:"오락과 자기 관찰용이며 진단이나 관계 조언이 아닙니다.",shareRequest:"한국어로 한 문장 요약, 짧은 해석, 실행 가능한 부드러운 제안 하나를 주세요."},
};

type TypeCopy = { name:string; line:string; strength:string; blindspot:string; action:string };
const CN_TYPES: Record<LoveDimension, TypeCopy> = {
  closeness:{name:"共鸣织者",line:"你通过持续的靠近与分享，让关系长出共同的生活。",strength:"你擅长让对方感到被放在心里。",blindspot:"联系变少时，你可能过快把距离理解成感情降温。",action:"不安时先说“我想和你靠近一点”，不要用追问代替需要。"}, autonomy:{name:"星轨旅人",line:"你相信相爱不是合并，而是两条轨道彼此照亮。",strength:"你尊重边界、成长与差异，让关系保有呼吸感。",blindspot:"压力下，独立可能被读成撤退。",action:"需要空间时，也说清楚何时回来连接。"}, expression:{name:"真心信使",line:"你的爱需要被说出来，也希望重要感受不必靠猜。",strength:"你让喜欢、感谢和需要变得清楚。",blindspot:"情绪很满时，直接可能变成要求立刻回应。",action:"先说感受和需要，再给对方一点消化时间。"}, stability:{name:"长夜灯塔",line:"你最相信的浪漫，是日复一日仍然亮着的那盏灯。",strength:"可靠、承诺与一致性，是你给关系的安全底座。",blindspot:"过度追求确定时，变化会像风险。",action:"在稳定计划里，留一个可以临时改变的小窗口。"}, romance:{name:"心火导演",line:"你会为爱创造情节，让熟悉的人再次被看见。",strength:"你擅长创造仪式、新鲜感和共同记忆。",blindspot:"平淡时，你可能怀疑心动减弱就是爱变少。",action:"把一次浪漫安排变成了解对方近况的机会。"}, repair:{name:"关系园丁",line:"你不期待关系永不受伤，更在意受伤之后能否一起修复。",strength:"你愿意回到问题，并把道歉变成实际改变。",blindspot:"太急于修好时，可能没给感受足够时间。",action:"先问：“你现在想被理解，还是想一起解决？”"},
};
const TYPE_NAMES: Record<Locale, Record<LoveDimension,string>> = {
  "zh-CN":{closeness:"共鸣织者",autonomy:"星轨旅人",expression:"真心信使",stability:"长夜灯塔",romance:"心火导演",repair:"关系园丁"}, "zh-TW":{closeness:"共鳴織者",autonomy:"星軌旅人",expression:"真心信使",stability:"長夜燈塔",romance:"心火導演",repair:"關係園丁"}, en:{closeness:"Resonance Weaver",autonomy:"Orbiting Voyager",expression:"Heart Messenger",stability:"Night Lighthouse",romance:"Spark Director",repair:"Relationship Gardener"}, ja:{closeness:"共鳴を編む人",autonomy:"星軌道の旅人",expression:"心の使者",stability:"夜の灯台",romance:"心火の演出家",repair:"関係の庭師"}, es:{closeness:"Tejedor de resonancia",autonomy:"Viajero orbital",expression:"Mensajero del corazón",stability:"Faro nocturno",romance:"Director de la chispa",repair:"Jardinero del vínculo"}, ko:{closeness:"공명 직조자",autonomy:"별궤도 여행자",expression:"진심의 전령",stability:"긴밤의 등대",romance:"마음불 연출가",repair:"관계 정원사"},
};
export function loveTypeCopy(locale: Locale, dimension: LoveDimension): TypeCopy {
  const base = CN_TYPES[dimension];
  if (locale === "zh-CN") return base;
  const labels = LOVE_LABELS[locale];
  const localized: Record<Exclude<Locale,"zh-CN">, Omit<TypeCopy,"name">> = {
    "zh-TW":{line:`在你的結果裡，${labels[dimension]}是最鮮明的關係傾向。`,strength:`你自然地把${labels[dimension]}帶進親密關係，這也是對方最容易感受到的力量。`,blindspot:"壓力之下，優點也可能變成自動反應，讓彼此少一點選擇空間。",action:"先清楚說出一個需要，再為對方的回答留出空間。"},
    en:{line:`${labels[dimension]} is the clearest light in your way of loving.`,strength:`You naturally bring ${labels[dimension].toLowerCase()} into close relationships.`,blindspot:"Under pressure, a strength can become automatic and leave less room for the other person.",action:"Name one need clearly, then make room for the other person's answer."},
    ja:{line:`今回の結果では、${labels[dimension]}があなたの愛し方に最も鮮明に表れています。`,strength:`親密な関係に${labels[dimension]}を自然に持ち込めることが、あなたの力です。`,blindspot:"プレッシャーの下では、長所が自動反応になり、相手の余地を狭めることがあります。",action:"必要なことを一つ言葉にし、その後で相手の答えを待ってみましょう。"},
    es:{line:`${labels[dimension]} es la luz más clara en tu manera de amar.`,strength:`Aportas ${labels[dimension].toLowerCase()} de forma natural a las relaciones íntimas.`,blindspot:"Bajo presión, una fortaleza puede volverse automática y dejar menos espacio a la otra persona.",action:"Expresa una necesidad con claridad y deja espacio para la respuesta de la otra persona."},
    ko:{line:`이번 결과에서는 ${labels[dimension]}이 당신의 사랑 방식에서 가장 선명하게 나타납니다.`,strength:`친밀한 관계에 ${labels[dimension]}을 자연스럽게 가져오는 것이 당신의 힘입니다.`,blindspot:"압박을 받으면 장점도 자동 반응이 되어 상대의 여지를 줄일 수 있습니다.",action:"필요 한 가지를 분명히 말한 뒤, 상대의 대답을 위한 공간을 남겨 보세요."},
  };
  return { name: TYPE_NAMES[locale][dimension], ...localized[locale] };
}
