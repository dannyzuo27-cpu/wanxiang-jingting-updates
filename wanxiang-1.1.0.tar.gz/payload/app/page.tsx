"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  DIMENSION_LABELS,
  LOCALE_NAMES,
  MESSAGES,
  QUESTION_TEXTS,
  SUPPORTED_LOCALES,
  normalizeLocale,
  type Locale,
} from "./i18n";
import LoveChamber from "./love-chamber";
import { LOVE_MESSAGES } from "./love-i18n";

type Dimension =
  | "pride" | "envy" | "wrath" | "sloth" | "greed" | "gluttony" | "lust"
  | "humility" | "kindness" | "patience" | "diligence" | "generosity" | "temperance" | "chastity";

type Question = {
  text: string;
  scores: Array<{ dimension: Dimension; reverse?: boolean }>;
};

const QUESTIONS: Question[] = [
  { text: "我经常觉得自己的判断、标准或能力明显高于周围大多数人。", scores: [{ dimension: "pride" }] },
  { text: "遇到让人生气的事情时，我通常能先了解完整情况，再决定如何回应。", scores: [{ dimension: "patience" }] },
  { text: "即使已经拥有足够多的资源或机会，我仍很难停止追求更多。", scores: [{ dimension: "greed" }] },
  { text: "即使别人获得了我也很想要的东西，我通常仍能真诚地祝福对方。", scores: [{ dimension: "kindness" }] },
  { text: "面对重要但枯燥的任务，我经常拖到压力已经很大才真正开始。", scores: [{ dimension: "sloth" }] },
  { text: "即使产生很强烈的吸引或冲动，我仍会先考虑边界、承诺和后果。", scores: [{ dimension: "chastity" }] },
  { text: "遇到特别喜欢的食物、内容、购物或娱乐时，我常常很难适时停下来。", scores: [{ dimension: "gluttony" }] },
  { text: "发现自己确实错了时，即使有些丢脸，我也能够直接承认。", scores: [{ dimension: "humility" }] },
  { text: "当我受到冒犯、不公平对待或无端批评时，我的第一反应通常是立即反击。", scores: [{ dimension: "wrath" }] },
  { text: "当自己有余力时，我愿意主动分享时间、资源或机会，即使没有直接回报。", scores: [{ dimension: "generosity" }] },
  { text: "当我迷上一个人、一件事或一种体验时，它很容易长时间占据我的注意力。", scores: [{ dimension: "lust" }] },
  { text: "即使没有人监督、也没有即时奖励，我通常仍能稳定完成答应过的事情。", scores: [{ dimension: "diligence" }] },
  { text: "看到与自己条件相近的人取得更大成功时，我很容易感到不舒服或不平衡。", scores: [{ dimension: "envy" }] },
  { text: "我能够享受喜欢的东西，同时清楚决定多少已经足够。", scores: [{ dimension: "temperance" }] },
  { text: "取得成绩时，如果别人没有充分认识到我的贡献，我会明显感到不满。", scores: [{ dimension: "pride" }] },
  { text: "即使情绪已经上来，我也通常能暂缓表达，避免让一时反应扩大问题。", scores: [{ dimension: "patience" }] },
  { text: "在资源有限的情况下，多为自己争取一些会让我更有安全感，即使别人因此得到更少。", scores: [{ dimension: "greed" }] },
  { text: "看到别人处于弱势或难堪时，我通常会本能地维护对方的尊严。", scores: [{ dimension: "kindness" }] },
  { text: "我有时会花很多时间准备、规划或寻找最佳方法，却迟迟没有真正开始行动。", scores: [{ dimension: "sloth" }] },
  { text: "我可以体验欲望和吸引，但不会轻易让它们替我决定关系或长期选择。", scores: [{ dimension: "chastity" }] },
  { text: "对让我愉快的东西，我常有“既然已经开始，就干脆再多一点”的倾向。", scores: [{ dimension: "gluttony" }] },
  { text: "即使对方资历、年龄或地位不如我，只要对方确实更懂，我也愿意认真学习。", scores: [{ dimension: "humility" }] },
  { text: "我会长时间记住别人对我的冒犯，并希望对方以某种方式付出代价。", scores: [{ dimension: "wrath" }] },
  { text: "发现一个有价值的机会时，我愿意把真正适合的人介绍进来，而不是只留给自己。", scores: [{ dimension: "generosity" }] },
  { text: "强烈的吸引经常让我为原本不打算做的事情寻找合理理由。", scores: [{ dimension: "lust" }] },
  { text: "即使当天没有动力，我也通常能把重要事情向前推进，而不是完全等待状态。", scores: [{ dimension: "diligence" }] },
  { text: "看到别人表现得比我好时，我有时会下意识寻找对方的缺点，以减轻自己的失落。", scores: [{ dimension: "envy" }] },
  { text: "面对喜欢的消费、娱乐或感官享受，我通常能按照事先决定的界限停止。", scores: [{ dimension: "temperance" }] },
  { text: "当别人低估我或质疑我时，我通常能够先确认事实，而不是急于证明自己更优秀。", scores: [{ dimension: "humility" }, { dimension: "pride", reverse: true }] },
  { text: "面对稀缺的好处或机会，我能在保障自己合理需要后，主动给别人留下应有的份额。", scores: [{ dimension: "generosity" }, { dimension: "greed", reverse: true }] },
  { text: "强烈吸引出现时，我仍能尊重既有承诺、他人边界和自己的长期选择。", scores: [{ dimension: "chastity" }, { dimension: "lust", reverse: true }] },
  { text: "一位我在意的人取得了我长期想要却没得到的成果时，即使心里失落，我仍愿意认真听对方分享，并为他庆祝。", scores: [{ dimension: "kindness" }, { dimension: "envy", reverse: true }] },
  { text: "在疲惫或压力很大时，即使刷内容、购物或吃东西能让我暂时放松，我也能在它开始挤占睡眠和计划前停下。", scores: [{ dimension: "temperance" }, { dimension: "gluttony", reverse: true }] },
  { text: "争执中发现自己可能误解了对方时，我愿意停下来重新确认，而不是为了保住立场继续强硬下去。", scores: [{ dimension: "patience" }, { dimension: "wrath", reverse: true }] },
  { text: "面对一个短期看不到成果的长期任务，我通常仍能按固定节奏推进，不靠最后期限逼自己行动。", scores: [{ dimension: "diligence" }, { dimension: "sloth", reverse: true }] },
];

const LABELS: Record<Dimension, string> = {
  pride: "傲慢", envy: "嫉妒", wrath: "暴怒", sloth: "懒惰", greed: "贪婪", gluttony: "暴食", lust: "欲望",
  humility: "谦卑", kindness: "仁爱", patience: "耐心", diligence: "勤勉", generosity: "慷慨", temperance: "节制", chastity: "自持",
};

const SINS: Dimension[] = ["pride", "envy", "wrath", "sloth", "greed", "gluttony", "lust"];
const VIRTUES: Dimension[] = ["humility", "kindness", "patience", "diligence", "generosity", "temperance", "chastity"];
const RADAR_ORDER: Dimension[] = ["lust", "chastity", "temperance", "generosity", "diligence", "patience", "kindness", "humility", "pride", "gluttony", "greed", "sloth", "wrath", "envy"];
type LivewareWindow = Window & typeof globalThis & {
  webkitAudioContext?: typeof AudioContext;
};

const CLAWCHAT_USER_ID_PATTERN = /^usr_[0-9A-HJKMNP-TV-Z]{26}$/;

const SIN_COPY: Record<string, { line: string; trigger: string; gift: string; risk: string }> = {
  pride: { line: "你不是一定要赢，只是不愿被轻易看低。", trigger: "能力被质疑、贡献被忽略，或标准被挑战时。", gift: "自信、判断力，以及把事情做到更高标准的动力。", risk: "为了证明自己而错过倾听，也让关系变成无形的竞赛。" },
  envy: { line: "别人的高光，有时会照见你尚未抵达的地方。", trigger: "与条件相近的人被认可、领先或得到你想要的机会时。", gift: "对差距敏锐，能迅速发现自己真正渴望的目标。", risk: "比较会消耗满足感，也可能让你低估自己的路径。" },
  wrath: { line: "你的怒意，往往比你的解释更早抵达现场。", trigger: "遭遇冒犯、不公、失控或边界被越过时。", gift: "行动果断，敢于保护边界，也能为不公发声。", risk: "即时反击可能扩大冲突，让正确的立场失去有效的表达。" },
  sloth: { line: "你并非没有能力，只是启动常比完成更困难。", trigger: "任务枯燥、回报遥远、标准模糊或压力尚未逼近时。", gift: "会寻找更省力的路径，也不容易盲目投入无意义的忙碌。", risk: "等待最佳状态，会让选择权逐渐变成截止日期的权力。" },
  greed: { line: "你追逐的未必是更多，可能是终于足够安全。", trigger: "资源稀缺、未来不确定，或需要与他人分配机会时。", gift: "有积累意识，善于为长期风险留下余地。", risk: "安全感的门槛不断上升，让拥有变成无法停止的任务。" },
  gluttony: { line: "真正难停下的，常常不是享受，而是下一次满足。", trigger: "食物、内容、购物或娱乐带来即时愉悦时。", gift: "感受力强，能充分投入并享受生活中的刺激与丰盛。", risk: "短期满足容易挤占时间、精力和原本设好的边界。" },
  lust: { line: "吸引一旦发生，你的注意力会迅速拥有自己的方向。", trigger: "遇到强烈吸引、迷恋或新鲜而令人兴奋的体验时。", gift: "热情、投入，能够感受到关系与体验中的强烈生命力。", risk: "冲动会替长期选择寻找理由，也可能模糊彼此的边界。" },
};

const VIRTUE_COPY: Record<string, { line: string; protects: string; fails: string; action: string }> = {
  humility: { line: "你有能力把自尊与事实分开。", protects: "它让你承认未知、修正判断，也能从意想不到的人身上学习。", fails: "当你感到被轻视，谦卑可能被证明自己的冲动取代。", action: "下一次想立刻反驳时，先问一个确认事实的问题。" },
  kindness: { line: "你看见的不只是输赢，还有人的处境。", protects: "它让你在竞争和比较中，仍能保留对他人尊严的关注。", fails: "当自己的需要长期被忽视，善意可能变成疲惫或隐性怨气。", action: "帮助别人之前，也明确说出自己真正能承担的范围。" },
  patience: { line: "你愿意给事实一点时间，再让情绪作答。", protects: "它降低误判，也让你在冲突中保留选择回应方式的空间。", fails: "当边界被连续侵犯，暂停可能迅速变成压抑或爆发。", action: "先暂停，但为回应设一个明确时间，而不是无限拖延。" },
  diligence: { line: "你不完全依赖状态，也能让承诺继续前进。", protects: "它帮助你跨过无聊与阻力，把意愿沉淀成稳定结果。", fails: "目标失去意义或负担持续过量时，稳定会被消耗殆尽。", action: "把重要任务缩小到一个今天即可完成的动作。" },
  generosity: { line: "你相信机会被分享，并不会因此失去价值。", protects: "它让资源流动，也更容易建立互信和长期合作。", fails: "当安全感不足，分享会被理解成对自己份额的威胁。", action: "先界定自己的合理需要，再决定可以真诚分享的部分。" },
  temperance: { line: "你允许自己享受，也保留决定停止的权力。", protects: "它让满足不必以失控为代价，长期目标也更少被即时诱惑打断。", fails: "疲惫、孤独或压力积累时，原有界限最容易松动。", action: "在开始享受之前，先决定结束的时间或数量。" },
  chastity: { line: "欲望可以被看见，但不必替你签下决定。", protects: "它维护关系边界、既有承诺和更长期的自我选择。", fails: "在强烈吸引与自我合理化同时出现时，边界会变得模糊。", action: "把长期选择写成一句明确规则，在冲动出现前决定底线。" },
};

function calculate(answers: number[]) {
  const buckets = Object.fromEntries(Object.keys(LABELS).map((key) => [key, [] as number[]])) as Record<Dimension, number[]>;
  QUESTIONS.forEach((question, index) => {
    const forward = (answers[index] - 1) * 25;
    question.scores.forEach(({ dimension, reverse }) => buckets[dimension].push(reverse ? 100 - forward : forward));
  });
  const scores = Object.fromEntries(Object.entries(buckets).map(([key, values]) => [key, Math.round(values.reduce((a, b) => a + b, 0) / values.length)])) as Record<Dimension, number>;
  const independentAverage = (dimension: Dimension) => {
    const values: number[] = [];
    QUESTIONS.slice(0, 28).forEach((question, index) => {
      if (question.scores.some((item) => item.dimension === dimension)) values.push((answers[index] - 1) * 25);
    });
    return values.reduce((a, b) => a + b, 0) / values.length;
  };
  const leaders = (group: Dimension[]) => {
    const highest = Math.max(...group.map((key) => scores[key]));
    const tied = group.filter((key) => scores[key] === highest);
    const bestIndependent = Math.max(...tied.map(independentAverage));
    return tied.filter((key) => independentAverage(key) === bestIndependent);
  };
  const sinAverage = SINS.reduce((sum, key) => sum + scores[key], 0) / 7;
  const virtueAverage = VIRTUES.reduce((sum, key) => sum + scores[key], 0) / 7;
  return { scores, primarySins: leaders(SINS), primaryVirtues: leaders(VIRTUES), difference: Math.round(virtueAverage - sinAverage) };
}

function Radar({ scores, locale }: { scores: Record<Dimension, number>; locale: Locale }) {
  const labels = DIMENSION_LABELS[locale];
  const m = MESSAGES[locale];
  const cx = 250, cy = 250, radius = 165;
  const point = (index: number, value: number) => {
    const angle = -Math.PI / 2 + (Math.PI * 2 * index) / RADAR_ORDER.length;
    const r = radius * value / 100;
    return [cx + Math.cos(angle) * r, cy + Math.sin(angle) * r];
  };
  const polygon = (values: number[]) => values.map((value, index) => point(index, value).join(",")).join(" ");
  const rings = [20, 40, 60, 80, 100].map((value) => polygon(RADAR_ORDER.map(() => value)));
  const sinPoints = polygon(RADAR_ORDER.map((key) => SINS.includes(key) ? scores[key] : 0));
  const virtuePoints = polygon(RADAR_ORDER.map((key) => VIRTUES.includes(key) ? scores[key] : 0));
  return (
    <div className="radar-wrap">
      <svg className="radar" viewBox="0 0 500 500" role="img" aria-label={m.radarAria}>
        {rings.map((ring, index) => <polygon key={ring} points={ring} className={index === 4 ? "grid grid-strong" : "grid"} />)}
        {RADAR_ORDER.map((_, index) => {
          const [x, y] = point(index, 100);
          return <line key={index} x1={cx} y1={cy} x2={x} y2={y} className="spoke" />;
        })}
        <polygon points={sinPoints} className="radar-sin" />
        <polygon points={virtuePoints} className="radar-virtue" />
        {RADAR_ORDER.map((key, index) => {
          const [x, y] = point(index, scores[key]);
          const [lx, ly] = point(index, 116);
          return <g key={key}>
            <circle cx={x} cy={y} r="4" className={SINS.includes(key) ? "dot-sin" : "dot-virtue"} />
            <text x={lx} y={ly - 4} textAnchor="middle" className="radar-label">{labels[key]}</text>
            <text x={lx} y={ly + 13} textAnchor="middle" className="radar-value">{scores[key]}</text>
          </g>;
        })}
      </svg>
      <div className="legend"><span><i className="legend-sin" />{m.sins}</span><span><i className="legend-virtue" />{m.virtues}</span></div>
    </div>
  );
}

export default function Home() {
  const [locale, setLocale] = useState<Locale>("zh-CN");
  const [activeChamber, setActiveChamber] = useState<"fourteen" | "love">("fourteen");
  const [heroSlide, setHeroSlide] = useState<0 | 1>(0);
  const [screen, setScreen] = useState<"intro" | "test" | "result">("intro");
  const [answers, setAnswers] = useState<number[]>(Array(QUESTIONS.length).fill(0));
  const [current, setCurrent] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [chosenValue, setChosenValue] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [agentUserId] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    const requested = new URLSearchParams(window.location.search).get("agent");
    return requested && CLAWCHAT_USER_ID_PATTERN.test(requested) ? requested : null;
  });
  const audioContextRef = useRef<AudioContext | null>(null);
  const transitionTimerRef = useRef<number | null>(null);

  useEffect(() => {
    localStorage.removeItem("wanxiang-fourteen-mirrors");
    const params = new URLSearchParams(window.location.search);
    const candidates = [params.get("lang"), localStorage.getItem("wanxiang-locale"), ...navigator.languages];
    const detected = candidates.map(normalizeLocale).find(Boolean) as Locale | undefined;
    const startupTimer = window.setTimeout(() => {
      if (detected) setLocale(detected);
      if (params.get("chamber") === "love") setActiveChamber("love");
      if (params.get("start") === "1") {
        setAnswers(Array(QUESTIONS.length).fill(0));
        setCurrent(0);
        setChosenValue(0);
        setIsTransitioning(false);
        setScreen("test");
      }
    }, 0);
    return () => {
      window.clearTimeout(startupTimer);
      if (transitionTimerRef.current) window.clearTimeout(transitionTimerRef.current);
    };
  }, []);

  useEffect(() => {
    document.documentElement.lang = locale;
    document.title = `${MESSAGES[locale].title} | ${MESSAGES[locale].brand}`;
  }, [locale]);

  useEffect(() => {
    if (screen !== "test") return;
    const onKey = (event: KeyboardEvent) => {
      const value = Number(event.key);
      if (value >= 1 && value <= 5) choose(value);
      if (event.key === "ArrowLeft" && current > 0) setCurrent(current - 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  useEffect(() => {
    if (screen !== "intro" || activeChamber !== "fourteen" || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => setHeroSlide((slide) => slide === 0 ? 1 : 0), 7000);
    return () => window.clearInterval(timer);
  }, [screen, activeChamber, heroSlide]);

  const completed = answers.filter(Boolean).length;
  const result = useMemo(() => completed === QUESTIONS.length ? calculate(answers) : null, [answers, completed]);

  function start() {
    const params = new URLSearchParams();
    if (agentUserId) params.set("agent", agentUserId);
    window.history.replaceState(null, "", `${window.location.pathname}${params.size ? `?${params}` : ""}`);
    if (transitionTimerRef.current) window.clearTimeout(transitionTimerRef.current);
    setAnswers(Array(QUESTIONS.length).fill(0));
    setCurrent(0);
    setChosenValue(0);
    setIsTransitioning(false);
    setScreen("test");
  }

  function leave() {
    setAnswers(Array(QUESTIONS.length).fill(0));
    setCurrent(0);
    setChosenValue(0);
    setIsTransitioning(false);
    setScreen("intro");
  }

  function changeLocale(next: Locale) {
    setLocale(next);
    localStorage.setItem("wanxiang-locale", next);
    document.documentElement.lang = next;
  }

  function openLoveChamber() {
    const params = new URLSearchParams(window.location.search);
    params.delete("start");
    params.set("chamber", "love");
    params.set("lang", locale);
    window.history.replaceState(null, "", `${window.location.pathname}?${params}`);
    setActiveChamber("love");
  }

  function returnToHall() {
    const params = new URLSearchParams(window.location.search);
    params.delete("chamber");
    params.delete("start");
    params.set("lang", locale);
    window.history.replaceState(null, "", `${window.location.pathname}?${params}`);
    setActiveChamber("fourteen");
    setScreen("intro");
  }

  function playMirrorTone(value: number, isFinal = false) {
    if (!soundEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as LivewareWindow).webkitAudioContext;
      if (!AudioContextClass) return;
      const context = audioContextRef.current ?? new AudioContextClass();
      audioContextRef.current = context;
      void context.resume();
      const now = context.currentTime;
      const base = [196, 220, 247, 294, 330][value - 1] ?? 247;
      const frequencies = isFinal ? [base, base * 1.5, base * 2] : [base, base * 2.01];
      frequencies.forEach((frequency, index) => {
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        oscillator.type = index === 0 ? "sine" : "triangle";
        oscillator.frequency.setValueAtTime(frequency, now);
        oscillator.frequency.exponentialRampToValueAtTime(frequency * 1.018, now + .32);
        gain.gain.setValueAtTime(.0001, now);
        gain.gain.exponentialRampToValueAtTime(index === 0 ? .075 : .025, now + .018 + index * .018);
        gain.gain.exponentialRampToValueAtTime(.0001, now + (isFinal ? .72 : .42) + index * .08);
        oscillator.connect(gain).connect(context.destination);
        oscillator.start(now + index * .045);
        oscillator.stop(now + (isFinal ? .82 : .52) + index * .08);
      });
    } catch {
      // Sound is decorative; unsupported or restricted audio must never block answering.
    }
  }

  function choose(value: number) {
    if (isTransitioning) return;
    const nextAnswers = [...answers];
    nextAnswers[current] = value;
    setAnswers(nextAnswers);
    setChosenValue(value);
    setIsTransitioning(true);
    const isFinal = current === QUESTIONS.length - 1;
    playMirrorTone(value, isFinal);
    transitionTimerRef.current = window.setTimeout(() => {
      if (isFinal) {
        if (nextAnswers.every(Boolean)) setScreen("result");
      } else {
        setCurrent((question) => question + 1);
      }
      setChosenValue(0);
      setIsTransitioning(false);
    }, isFinal ? 720 : 460);
  }

  function resultMessage() {
    if (!result) return "";
    const labels = DIMENSION_LABELS[locale];
    const m = MESSAGES[locale];
    const sin = result.primarySins.map((key) => labels[key]).join("/");
    const virtue = result.primaryVirtues.map((key) => labels[key]).join("/");
    const scoreLine = RADAR_ORDER.map((key) => `${labels[key]} ${result.scores[key]}`).join(", ");
    return `[万象镜厅结果｜十四面镜] language=${locale}; ${m.sinLeader}: ${sin} ${result.scores[result.primarySins[0]]}; ${m.virtueLeader}: ${virtue} ${result.scores[result.primaryVirtues[0]]}; ${m.difference}: ${result.difference >= 0 ? "+" : ""}${result.difference}; 14D: ${scoreLine}. ${m.shareRequest}`;
  }

  function resultChatLink(): string | null {
    if (!agentUserId) return null;
    const query = new URLSearchParams({ chat: "1", draft: resultMessage() });
    return `clawchat://u/${agentUserId}?${query.toString()}`;
  }

  const m = MESSAGES[locale];
  const labels = DIMENSION_LABELS[locale];
  const languagePicker = (
    <label className="language-picker">
      <span className="sr-only">{m.language}</span>
      <select value={locale} onChange={(event) => changeLocale(event.target.value as Locale)} aria-label={m.language}>
        {SUPPORTED_LOCALES.map((item) => <option key={item} value={item}>{LOCALE_NAMES[item]}</option>)}
      </select>
    </label>
  );
  const brand = <button className="brand" onClick={leave} aria-label={m.backHome}><span className="brand-mark" aria-hidden="true">◇</span><span>{m.brand}</span></button>;

  if (activeChamber === "love") return <LoveChamber locale={locale} onLocale={changeLocale} agentUserId={agentUserId} onBack={returnToHall} />;

  if (screen === "intro") return (
    <main className="site-shell intro-page">
      <header className="topbar">{brand}<div className="topbar-actions"><span className="edition">MIRROR HALL · 01</span>{languagePicker}</div></header>
      <section className={`hero hero-carousel hero-slide-${heroSlide + 1}`} aria-roledescription="carousel" aria-label="镜室推荐">
        <div className="hero-stage" key={heroSlide}>
          {heroSlide === 0 ? <>
            <div className="hero-copy">
              <p className="eyebrow">{m.chamberOpen}</p><h1>{m.title}</h1><p className="subtitle">{m.subtitle}</p><p className="intro-text">{m.intro}</p>
              <div className="hero-actions"><a className="primary" href={`?start=1&lang=${locale}`} onClick={(event) => { event.preventDefault(); start(); }}>{m.enter}<span>→</span></a></div>
              <div className="meta-row"><span>{m.questionCount}</span><span>{m.duration}</span><span>{m.reportMeta}</span></div>
            </div>
            <div className="mirror-art" aria-hidden="true"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="mirror-frame generated-frame"><img src="/mirror-hall-hero.webp" alt="" /><span className="image-vignette" /></div><div className="ornament ornament-left">✦</div><div className="ornament ornament-right">✦</div><p>THE FOURTEEN MIRRORS</p></div>
          </> : <>
            <div className="hero-copy love-slide-copy">
              <p className="eyebrow">{LOVE_MESSAGES[locale].chamber}</p><h1>{LOVE_MESSAGES[locale].title}</h1><p className="subtitle">{LOVE_MESSAGES[locale].subtitle}</p><p className="intro-text">{LOVE_MESSAGES[locale].intro}</p>
              <div className="hero-actions"><button className="primary love-primary" onClick={openLoveChamber}>{LOVE_MESSAGES[locale].enter}<span>→</span></button></div>
              <div className="meta-row"><span>{LOVE_MESSAGES[locale].questionCount}</span><span>{LOVE_MESSAGES[locale].duration}</span><span>{LOVE_MESSAGES[locale].reportMeta}</span></div>
            </div>
            <div className="love-hero-art" aria-hidden="true"><div className="orbit love-orbit-one"/><div className="orbit love-orbit-two"/><div className="love-hero-frame"><img src="/heart-prism-hero.webp" alt=""/><span/></div><div className="ornament ornament-left">♡</div><div className="ornament ornament-right">✦</div><p>THE HEART PRISM</p></div>
          </>}
        </div>
        <div className="carousel-controls" role="group" aria-label="切换镜室">
          {[0, 1].map((slide) => <button key={slide} type="button" className={heroSlide === slide ? "active" : ""} aria-label={slide === 0 ? m.title : LOVE_MESSAGES[locale].title} aria-current={heroSlide === slide ? "true" : undefined} onClick={() => setHeroSlide(slide as 0 | 1)}><span>{String(slide + 1).padStart(2, "0")}</span></button>)}
        </div>
      </section>
      <section className="chamber-gallery" aria-labelledby="chamber-gallery-title">
        <div className="chamber-gallery-head"><p>THE MIRROR DIRECTORY</p><h2 id="chamber-gallery-title">镜室目录</h2><span>每一间镜室，观察一种不同的你。</span></div>
        <div className="chamber-cards">
          <article className="chamber-card chamber-card-current"><img className="chamber-card-art chamber-card-mirror-art" src="/mirror-hall-hero.webp" alt=""/><span>01</span><p>THE FOURTEEN MIRRORS</p><h3>{m.title}</h3><small>{m.subtitle}</small><button className="text-button" onClick={start}>{m.enter} →</button></article>
          <article className="chamber-card chamber-card-love"><img className="chamber-card-art" src="/heart-prism-hero.webp" alt=""/><span>02</span><p>THE HEART PRISM</p><h3>{LOVE_MESSAGES[locale].title}</h3><small>{LOVE_MESSAGES[locale].subtitle}</small><button className="text-button" onClick={openLoveChamber}>{LOVE_MESSAGES[locale].enter} →</button></article>
        </div>
      </section>
      <section className="threshold">
        <p>{m.before}</p>
        <div className="threshold-grid">
          {m.thresholds.map((item, index) => <article key={item.title}><span>{String(index + 1).padStart(2, "0")}</span><h2>{item.title}</h2><p>{item.body}</p></article>)}
        </div>
      </section>
      <footer><span>{m.brand}</span><span>{m.motto}</span></footer>
    </main>
  );

  if (screen === "test") {
    const progress = Math.round((completed / QUESTIONS.length) * 100);
    return (
      <main className="site-shell test-page">
        <header className="topbar">{brand}<div className="test-tools">{languagePicker}<button className="sound-toggle" type="button" aria-pressed={soundEnabled} onClick={() => setSoundEnabled((enabled) => !enabled)}><span aria-hidden="true">{soundEnabled ? "◉" : "○"}</span>{soundEnabled ? m.soundOn : m.soundOff}</button><button className="exit-button" onClick={leave}>{m.exit}</button></div></header>
        <div className="test-layout">
          <aside className="test-aside">
            <p className="eyebrow">{m.chamberOpen.split("·")[0]}</p><h1>{m.title}</h1>
            <p className="test-subtitle">{m.subtitle}</p>
            <div className="progress-number"><strong>{String(current + 1).padStart(2, "0")}</strong><span>/ 35</span></div>
            <div className="progress-track"><i style={{ width: `${Math.max(progress, 2)}%` }} /></div>
            <p className="aside-note">{m.temporary}</p>
          </aside>
          <section className={isTransitioning ? "question-panel is-transitioning" : "question-panel"} aria-live="polite">
            <div className="mirror-transition" aria-hidden="true"><i /><i /><i /></div>
            <div className="question-card" key={current}>
              <span className="question-watermark" aria-hidden="true">{String(current + 1).padStart(2, "0")}</span>
              <div className="question-kicker"><span>MIRROR QUESTION</span><span>{String(current + 1).padStart(2, "0")}</span></div>
              <h2>{QUESTION_TEXTS[locale][current]}</h2>
              <div className="question-seal" aria-hidden="true"><i /><span>{m.firstReaction}</span><i /></div>
            </div>
            <div className={isTransitioning ? "answer-deck resolving" : "answer-deck"}>
              <div className="answer-deck-head" aria-hidden="true"><span>{m.responseScale}</span><i /><span>{isTransitioning ? current === QUESTIONS.length - 1 ? m.closing : m.nextMirror : m.chooseMirror}</span></div>
              <div className="scale-labels" aria-hidden="true">
                <span>{m.scaleLow}</span><span>{m.scaleMid}</span><span>{m.scaleHigh}</span>
              </div>
              <div className="options" role="group" aria-label={m.chooseAnswer}>
                {m.options.map((label, index) => (
                  <button
                    key={`${current}-${label}`}
                    type="button"
                    aria-label={`${index + 1}，${label}`}
                    title={label}
                    disabled={isTransitioning}
                    className={chosenValue === index + 1 ? "option chosen" : answers[current] === index + 1 ? "option selected" : "option"}
                    onClick={(event) => {
                      event.currentTarget.blur();
                      choose(index + 1);
                    }}
                  />
                ))}
              </div>
            </div>
            <div className="question-nav">
              <button disabled={current === 0 || isTransitioning} onClick={() => { setChosenValue(0); setCurrent(current - 1); }}>← {m.previous}</button>
              <span>{m.keyboard}</span>
            </div>
          </section>
        </div>
      </main>
    );
  }

  if (!result) return null;
  const resultChatUrl = resultChatLink();
  const primarySin = result.primarySins[0];
  const primaryVirtue = result.primaryVirtues[0];
  const differenceLabel = `${result.difference >= 0 ? "+" : ""}${result.difference}`;
  const sinCopy = locale === "zh-CN" ? SIN_COPY[primarySin] : {
    line: m.sinSummary(labels[primarySin]), trigger: m.genericTrigger, gift: m.genericGift, risk: m.genericRisk,
  };
  const virtueCopy = locale === "zh-CN" ? VIRTUE_COPY[primaryVirtue] : {
    line: m.virtueSummary(labels[primaryVirtue]), protects: m.genericProtects, fails: m.genericFails, action: m.genericAdvice,
  };
  return (
    <main className="site-shell result-page">
      <header className="topbar">{brand}<div className="topbar-actions">{languagePicker}{resultChatUrl ? <a className="secondary compact" href={resultChatUrl}>{m.returnChat}</a> : null}</div></header>
      <section className="result-hero">
        <p className="eyebrow">{m.reportTitle} · {new Date().toLocaleDateString(locale)}</p>
        <h1>{sinCopy.line}</h1>
        <p>{m.reportNote}</p>
        <div className="result-summary">
          <article className="summary-sin"><span>{m.sinLeader}</span><strong>{labels[primarySin]}</strong><b><em>{result.scores[primarySin]}</em>{m.points}</b></article>
          <article className="summary-virtue"><span>{m.virtueLeader}</span><strong>{labels[primaryVirtue]}</strong><b><em>{result.scores[primaryVirtue]}</em>{m.points}</b></article>
        </div>
        <div className="result-difference"><span>{m.difference}</span><strong>{differenceLabel}</strong></div>
      </section>
      <section className="report-section radar-section">
        <div className="section-heading"><p>01 · THE PROFILE</p><h2>{m.radarTitle}</h2><span>{m.radarNote}</span></div>
        <Radar scores={result.scores} locale={locale} />
        <div className="score-ledger">
          <div><h3>{m.sins}</h3>{SINS.map((key) => <p key={key}><span>{labels[key]}</span><i><b style={{ width: `${result.scores[key]}%` }} /></i><strong>{result.scores[key]}</strong></p>)}</div>
          <div><h3>{m.virtues}</h3>{VIRTUES.map((key) => <p key={key}><span>{labels[key]}</span><i><b style={{ width: `${result.scores[key]}%` }} /></i><strong>{result.scores[key]}</strong></p>)}</div>
        </div>
      </section>
      <section className="report-section analysis-grid">
        <article className="analysis-card dark-card">
          <p>02 · YOUR SHADOW</p><div className="card-title"><span>{m.dominantSin}</span><strong>{labels[primarySin]}</strong></div>
          <blockquote>{sinCopy.line}</blockquote>
          <dl><div><dt>{m.trigger}</dt><dd>{sinCopy.trigger}</dd></div><div><dt>{m.gift}</dt><dd>{sinCopy.gift}</dd></div><div><dt>{m.risk}</dt><dd>{sinCopy.risk}</dd></div></dl>
        </article>
        <article className="analysis-card light-card">
          <p>03 · YOUR VIRTUE</p><div className="card-title"><span>{m.coreVirtue}</span><strong>{labels[primaryVirtue]}</strong></div>
          <blockquote>{virtueCopy.line}</blockquote>
          <dl><div><dt>{m.protects}</dt><dd>{virtueCopy.protects}</dd></div><div><dt>{m.fails}</dt><dd>{virtueCopy.fails}</dd></div><div><dt>{m.advice}</dt><dd>{virtueCopy.action}</dd></div></dl>
        </article>
      </section>
      <section className="guide-share-card" aria-labelledby="guide-share-title">
        <div className="guide-share-mark" aria-hidden="true"><span>◇</span><i /></div>
        <div className="guide-share-copy">
          <p>04 · A GENTLE READING</p>
          <h2 id="guide-share-title">{m.deeperTitle}</h2>
          <span>{m.deeperBody}</span>
        </div>
        <div className="guide-share-action">
          {resultChatUrl ? <a className="primary" href={resultChatUrl}>{m.returnChat}<span>→</span></a> : null}
          <small>{resultChatUrl ? m.draftHint : m.agentLinkRequired}</small>
        </div>
      </section>
      <section className="closing-card">
        <span className="brand-mark">◇</span><p>{m.choiceRemains}</p>
        <div><button className="text-button" onClick={start}>{m.again}</button></div>
      </section>
      <footer><span>{m.footerTitle}</span><span>{m.disclaimer}</span></footer>
    </main>
  );
}
