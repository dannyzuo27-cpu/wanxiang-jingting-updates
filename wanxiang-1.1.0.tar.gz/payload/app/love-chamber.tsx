"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { LOCALE_NAMES, SUPPORTED_LOCALES, type Locale } from "./i18n";
import { LOVE_DIMENSIONS, LOVE_GROWTH_LABELS, LOVE_LABELS, LOVE_MESSAGES, LOVE_QUESTION_DIMENSIONS, LOVE_QUESTIONS, LOVE_TIED_LABELS, loveLowPoint, loveMatch, loveTags, loveTypeCopy, loveVerdict, type LoveDimension } from "./love-i18n";

type Props = { locale:Locale; onLocale:(locale:Locale)=>void; agentUserId:string|null; onBack:()=>void };
type Screen = "intro" | "test" | "result";

function calculate(answers:number[]) {
  const buckets = Object.fromEntries(LOVE_DIMENSIONS.map((key) => [key, [] as number[]])) as Record<LoveDimension, number[]>;
  answers.forEach((answer, index) => buckets[LOVE_QUESTION_DIMENSIONS[index]].push((answer - 1) * 25));
  const scores = Object.fromEntries(LOVE_DIMENSIONS.map((key) => [key, Math.round(buckets[key].reduce((sum, value) => sum + value, 0) / buckets[key].length)])) as Record<LoveDimension, number>;
  const order = [...LOVE_DIMENSIONS].sort((a, b) => scores[b] - scores[a]);
  return { scores, primary:order[0], secondary:order[1], growth:order[order.length-1] };
}

function radarPoint(index:number, value:number, radius=162, center=210) {
  const angle=(Math.PI*2*index)/LOVE_DIMENSIONS.length-Math.PI/2;
  const distance=radius*(value/100);
  return `${center+Math.cos(angle)*distance},${center+Math.sin(angle)*distance}`;
}

function LoveRadar({scores,labels}:{scores:Record<LoveDimension,number>;labels:Record<LoveDimension,string>}) {
  const center=210; const radius=162;
  const rings=[20,40,60,80,100];
  const polygon=LOVE_DIMENSIONS.map((key,index)=>radarPoint(index,scores[key],radius,center)).join(" ");
  return <div className="love-radar-wrap"><svg className="love-radar" viewBox="0 0 420 420" role="img" aria-label={LOVE_DIMENSIONS.map((key)=>`${labels[key]} ${scores[key]}`).join("，")}>
    {rings.map((level)=><polygon key={level} className={level===100?"love-radar-grid strong":"love-radar-grid"} points={LOVE_DIMENSIONS.map((_,index)=>radarPoint(index,level,radius,center)).join(" ")}/>) }
    {LOVE_DIMENSIONS.map((key,index)=>{const [x,y]=radarPoint(index,100,radius,center).split(",");return <line key={key} className="love-radar-spoke" x1={center} y1={center} x2={x} y2={y}/>})}
    <polygon className="love-radar-shape" points={polygon}/>
    {LOVE_DIMENSIONS.map((key,index)=>{const [x,y]=radarPoint(index,scores[key],radius,center).split(",").map(Number);const [lx,ly]=radarPoint(index,116,radius,center).split(",").map(Number);return <g key={key}><circle className="love-radar-dot" cx={x} cy={y} r="4"/><text className="love-radar-label" x={lx} y={ly-3} textAnchor="middle">{labels[key]}</text><text className="love-radar-value" x={lx} y={ly+13} textAnchor="middle">{scores[key]}</text></g>})}
  </svg></div>;
}

export default function LoveChamber({ locale, onLocale, agentUserId, onBack }:Props) {
  const [screen, setScreen] = useState<Screen>("intro");
  const [answers, setAnswers] = useState<number[]>(Array(LOVE_QUESTION_DIMENSIONS.length).fill(0));
  const [current, setCurrent] = useState(0);
  const [chosen, setChosen] = useState(0);
  const [transitioning, setTransitioning] = useState(false);
  const audioRef = useRef<AudioContext|null>(null);
  const timerRef = useRef<number|null>(null);
  const m = LOVE_MESSAGES[locale];
  const labels = LOVE_LABELS[locale];
  const complete = answers.filter(Boolean).length;
  const result = useMemo(() => complete === answers.length ? calculate(answers) : null, [answers, complete]);

  useEffect(() => () => { if (timerRef.current) window.clearTimeout(timerRef.current); }, []);
  useEffect(() => { document.title = `${m.title} | ${locale === "zh-CN" ? "万象镜厅" : "Mirror Hall"}`; }, [locale, m.title]);

  function reset(next:Screen="test") {
    if (timerRef.current) window.clearTimeout(timerRef.current);
    setAnswers(Array(LOVE_QUESTION_DIMENSIONS.length).fill(0)); setCurrent(0); setChosen(0); setTransitioning(false); setScreen(next);
  }
  function leave() { reset("intro"); }
  function tone(value:number, final=false) {
    try {
      const Ctx = window.AudioContext;
      const context = audioRef.current ?? new Ctx(); audioRef.current = context; void context.resume();
      const now = context.currentTime; const base = [196,220,247,294,330][value-1];
      [base, base * 1.5].forEach((frequency, index) => { const oscillator=context.createOscillator(); const gain=context.createGain(); oscillator.type=index?"triangle":"sine"; oscillator.frequency.setValueAtTime(frequency,now); gain.gain.setValueAtTime(.0001,now); gain.gain.exponentialRampToValueAtTime(index?.022:.055,now+.02); gain.gain.exponentialRampToValueAtTime(.0001,now+(final?.72:.38)); oscillator.connect(gain).connect(context.destination); oscillator.start(now+index*.04); oscillator.stop(now+(final?.8:.46)); });
    } catch { /* Decorative audio must never block the test. */ }
  }
  function choose(value:number) {
    if (transitioning) return;
    const next=[...answers]; next[current]=value; setAnswers(next); setChosen(value); setTransitioning(true);
    const final=current===answers.length-1; tone(value,final);
    timerRef.current=window.setTimeout(() => { if (final && next.every(Boolean)) setScreen("result"); else if (!final) setCurrent((value)=>value+1); setChosen(0); setTransitioning(false); }, final?650:430);
  }
  function shareText() {
    if (!result) return "";
    const primary=loveTypeCopy(locale,result.primary); const secondary=loveTypeCopy(locale,result.secondary);
    const scoreLine=LOVE_DIMENSIONS.map((key)=>`${labels[key]} ${result.scores[key]}`).join(", ");
    return `[万象镜厅结果｜心动棱镜] language=${locale}; ${m.primary}: ${primary.name}; ${m.secondary}: ${secondary.name}; 6D: ${scoreLine}. ${m.shareRequest}`;
  }
  const chatUrl = result && agentUserId ? `clawchat://u/${agentUserId}?${new URLSearchParams({chat:"1",draft:shareText()})}` : null;
  const languagePicker = <label className="language-picker"><span className="sr-only">Language</span><select value={locale} onChange={(event)=>onLocale(event.target.value as Locale)}>{SUPPORTED_LOCALES.map((item)=><option key={item} value={item}>{LOCALE_NAMES[item]}</option>)}</select></label>;
  const header = <header className="topbar love-topbar"><button className="brand" onClick={onBack}><span className="brand-mark love-mark">◇</span><span>{m.back}</span></button><div className="topbar-actions"><span className="edition">MIRROR HALL · 02</span>{languagePicker}</div></header>;

  if (screen === "intro") return <main className="site-shell love-page love-intro">
    {header}
    <section className="love-hero">
      <div className="love-hero-copy"><p className="eyebrow">{m.chamber}</p><h1>{m.title}</h1><p className="subtitle">{m.subtitle}</p><p className="intro-text">{m.intro}</p><button className="primary love-primary" onClick={()=>reset()}>{m.enter}<span>→</span></button><div className="meta-row"><span>{m.questionCount}</span><span>{m.duration}</span><span>{m.reportMeta}</span></div></div>
      <div className="prism-art" aria-hidden="true"><div className="prism-orbit prism-orbit-a"/><div className="prism-orbit prism-orbit-b"/><div className="prism-image-frame"><img src="/heart-prism-hero.webp" alt=""/><span/></div><p>THE HEART PRISM</p></div>
    </section>
    <section className="love-threshold"><p>LOVE IS A WAY OF RELATING</p><h2>{m.reportMeta}</h2><div>{LOVE_DIMENSIONS.map((key,index)=><span key={key}><b>{String(index+1).padStart(2,"0")}</b>{labels[key]}</span>)}</div><small>{m.privacy}<br/>{m.disclaimer}</small></section>
  </main>;

  if (screen === "test") {
    const progress=Math.round((complete/answers.length)*100);
    return <main className="site-shell test-page love-test">{header}<div className="test-layout">
      <aside className="test-aside love-aside"><p className="eyebrow">CHAMBER II</p><h1>{m.title}</h1><p className="test-subtitle">{m.subtitle}</p><div className="progress-number"><strong>{String(current+1).padStart(2,"0")}</strong><span>/ {answers.length}</span></div><div className="progress-track"><i style={{width:`${Math.max(progress,2)}%`}}/></div><p className="aside-note">{m.privacy}</p></aside>
      <section className={transitioning?"question-panel love-question is-transitioning":"question-panel love-question"} aria-live="polite"><div className="mirror-transition"><i/><i/><i/></div><div className="question-card" key={current}><span className="question-watermark">{String(current+1).padStart(2,"0")}</span><div className="question-kicker"><span>HEART QUESTION</span><span>{String(current+1).padStart(2,"0")}</span></div><h2>{LOVE_QUESTIONS[locale][current]}</h2><div className="question-seal"><i/><span>{m.choose}</span><i/></div></div>
      <div className={transitioning?"answer-deck resolving":"answer-deck"}><div className="scale-labels"><span>{m.scaleLow}</span><span>{m.scaleMid}</span><span>{m.scaleHigh}</span></div><div className="options love-options" role="group" aria-label={m.choose}>{[1,2,3,4,5].map((value)=><button key={`${current}-${value}`} aria-label={`${value}`} disabled={transitioning} className={chosen===value?"option chosen":answers[current]===value?"option selected":"option"} onClick={(event)=>{event.currentTarget.blur();choose(value)}}/>)}</div></div>
      <div className="question-nav"><button disabled={current===0||transitioning} onClick={()=>{setChosen(0);setCurrent(current-1)}}>← {m.previous}</button><button onClick={leave}>{m.exit}</button></div></section>
    </div></main>;
  }

  if (!result) return null;
  const primary=loveTypeCopy(locale,result.primary); const secondary=loveTypeCopy(locale,result.secondary); const growth=loveTypeCopy(locale,result.growth);
  const tied=result.scores[result.primary]===result.scores[result.secondary];
  const verdict=loveVerdict(locale,result.primary,result.secondary,tied);
  const tags=loveTags(locale,result.primary,result.secondary,result.growth);
  return <main className="site-shell love-page love-result">{header}
    <section className="love-result-cover"><img src="/heart-result-hero.webp" alt=""/><div className="love-result-hero"><p className="eyebrow">{m.report}</p><div className="result-sigil"><span>II</span></div><h1>{tied?`${labels[result.primary]} × ${labels[result.secondary]}`:primary.name}</h1><blockquote className="love-verdict">{verdict}</blockquote><div className="love-share-tags">{tags.map((tag)=><span key={tag}>#{tag}</span>)}</div><div className="love-result-pair love-result-triad"><article><span>{tied?LOVE_TIED_LABELS[locale]:m.primary}</span><strong>{labels[result.primary]}</strong><b>{primary.name} · {result.scores[result.primary]}</b></article><article><span>{tied?LOVE_TIED_LABELS[locale]:m.secondary}</span><strong>{labels[result.secondary]}</strong><b>{secondary.name} · {result.scores[result.secondary]}</b></article><article><span>{LOVE_GROWTH_LABELS[locale]}</span><strong>{labels[result.growth]}</strong><b>{growth.name} · {result.scores[result.growth]}</b></article></div><p>{m.reportNote}</p></div></section>
    <section className="love-profile"><div className="section-heading"><p>01 · LOVE SPECTRUM</p><h2>{m.profile}</h2></div><LoveRadar scores={result.scores} labels={labels}/><div className="love-bars">{LOVE_DIMENSIONS.map((key)=><div key={key} className={key===result.primary?"is-primary":key===result.growth?"is-growth":""}><span>{labels[key]}</span><i><b style={{width:`${result.scores[key]}%`}}/></i><strong>{result.scores[key]}</strong></div>)}</div></section>
    <section className="love-reading"><article><span>02 · WHAT YOU NEED</span><h2>{m.strength}</h2><p>{verdict}</p></article><article><span>03 · WHERE IT GETS STUCK</span><h2>{m.blindspot}</h2><p>{loveLowPoint(locale,result.growth)}</p></article><article className="love-action"><span>04 · HOW TO LOVE YOU</span><h2>{m.action}</h2><p>{loveMatch(locale,result.primary)}</p></article></section>
    <section className="guide-share-card love-share"><div className="guide-share-mark"><span>♡</span><i/></div><div className="guide-share-copy"><p>05 · A GENTLE READING</p><h2>{m.shareTitle}</h2><span>{m.shareBody}</span></div><div className="guide-share-action">{chatUrl?<a className="primary love-primary" href={chatUrl}>{m.returnChat}<span>→</span></a>:null}<small>{chatUrl?m.draftHint:m.agentRequired}</small></div></section>
    <section className="closing-card"><span className="brand-mark love-mark">◇</span><p>{m.reportNote}</p><div><button className="text-button" onClick={()=>reset()}>{m.again}</button><button className="text-button" onClick={onBack}>{m.back}</button></div></section><footer><span>{m.title} · CHAMBER II</span><span>{m.disclaimer}</span></footer>
  </main>;
}
