import type { Metadata } from "next";
import { headers } from "next/headers";
import "./globals.css";
import { MESSAGES, normalizeLocale, type Locale } from "./i18n";

async function requestLocale(): Promise<Locale> {
  const requestHeaders = await headers();
  const acceptLanguage = requestHeaders.get("accept-language") ?? "";
  for (const entry of acceptLanguage.split(",")) {
    const locale = normalizeLocale(entry.split(";")[0]);
    if (locale) return locale;
  }
  return "zh-CN";
}

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host") ?? "app-1bdb629a56d0a285.apps.clawling.io";
  const protocol = requestHeaders.get("x-forwarded-proto") ?? (host.includes("localhost") ? "http" : "https");
  const origin = `${protocol}://${host}`;
  const locale = await requestLocale();
  const m = MESSAGES[locale];
  const title = `${m.title} | ${m.brand}`;
  const description = `${m.subtitle}. ${m.reportNote}`;

  return {
    metadataBase: new URL(origin),
    title,
    description,
    openGraph: {
      type: "website",
      title,
      description,
      images: [{ url: `${origin}/og.png`, width: 1731, height: 909, alt: `${m.brand} · ${m.title}` }],
    },
    twitter: { card: "summary_large_image", title, description, images: [`${origin}/og.png`] },
  };
}

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const locale = await requestLocale();
  return <html lang={locale}><body>{children}</body></html>;
}
