import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request("https://example.com/", { headers: { accept: "text/html", host: "example.com" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("renders the Fourteen Mirrors experience and social metadata", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /十四面镜 \| 万象镜厅/);
  assert.match(html, /七宗罪 × 七美德人格测试/);
  assert.match(html, /https:\/\/example\.com\/og\.png/);
  assert.doesNotMatch(html, /codex-preview|Your site is taking shape/);
});

test("keeps result sharing private, explicit, and agent-oriented", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  const i18n = await readFile(new URL("../app/i18n.ts", import.meta.url), "utf8");
  const soul = await readFile(new URL("../liveware/SOUL.md", import.meta.url), "utf8");
  const skill = await readFile(new URL("../liveware/skills/wanxiang-jingting/SKILL.md", import.meta.url), "utf8");

  assert.match(page, /\[万象镜厅结果｜十四面镜\]/);
  assert.match(i18n, /带结果返回对话/);
  assert.match(page, /clawchat:\/\/u\//);
  assert.match(page, /URLSearchParams\(window\.location\.search\)\.get\("agent"\)/);
  assert.match(page, /if \(!agentUserId\) return null/);
  assert.doesNotMatch(page, /const CLAWCHAT_AGENT_USER_ID/);
  assert.doesNotMatch(page, /usr_[0-9A-HJKMNP-TV-Z]{26}/);
  assert.match(page, /chat: "1", draft:/);
  assert.match(i18n, /自动填入对话输入框/);
  assert.doesNotMatch(page, /navigator\.clipboard/);
  assert.match(i18n, /下一面镜正在显影/);
  assert.match(i18n, /镜音开启/);
  assert.match(i18n, /不包含单题答案/);
  assert.match(soul, /结果陪读与正向心理引导/);
  assert.match(soul, /不保存、归档或复用本次报告/);
  assert.match(skill, /用户分享结果后的陪读/);
  assert.match(skill, /300—450个中文字符/);
  assert.match(skill, /一句话看懂/);
  assert.match(skill, /简短总结/);
  assert.match(skill, /具体拆解/);
  assert.match(skill, /\*\*一个小行动\*\*/);
  assert.match(skill, /不用表格/);
  assert.match(skill, /不得写“上一次、这一次、另一面、前后变化、判若两人”/);
  assert.match(skill, /本次作答较极端，结果只适合粗略参考/);
  await access(new URL("../public/og.png", import.meta.url));
});

test("supports all six ClawChat languages across the complete test", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  const i18n = await readFile(new URL("../app/i18n.ts", import.meta.url), "utf8");

  assert.match(i18n, /SUPPORTED_LOCALES = \["en", "zh-CN", "zh-TW", "ja", "es", "ko"\]/);
  assert.match(page, /navigator\.languages/);
  assert.match(page, /wanxiang-locale/);
  assert.match(page, /QUESTION_TEXTS\[locale\]\[current\]/);
  assert.match(page, /DIMENSION_LABELS\[locale\]/);
  assert.match(page, /language=\$\{locale\}/);
  assert.match(i18n, /English/);
  assert.match(i18n, /繁體中文/);
  assert.match(i18n, /日本語/);
  assert.match(i18n, /Español/);
  assert.match(i18n, /한국어/);
});

test("includes the original multilingual Heart Prism chamber", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  const chamber = await readFile(new URL("../app/love-chamber.tsx", import.meta.url), "utf8");
  const i18n = await readFile(new URL("../app/love-i18n.ts", import.meta.url), "utf8");

  assert.match(page, /THE HEART PRISM/);
  assert.match(page, /LOVE_MESSAGES\[locale\]/);
  assert.match(chamber, /\[万象镜厅结果｜心动棱镜\]/);
  assert.match(chamber, /clawchat:\/\/u\//);
  assert.match(chamber, /answers\.filter\(Boolean\)/);
  assert.match(i18n, /心动棱镜/);
  assert.match(i18n, /LOVE_QUESTIONS: Record<Locale, string\[\]>/);
  assert.match(i18n, /"zh-TW"/);
  assert.match(i18n, /한국어/);
});
