import unittest
import sys
import types
from urllib.parse import parse_qs, urlsplit

gateway = types.ModuleType("clawchat_gateway")
protocol = types.ModuleType("clawchat_gateway.protocol")
protocol.new_message_id = lambda: "msg_test"
sys.modules.setdefault("clawchat_gateway", gateway)
sys.modules.setdefault("clawchat_gateway.protocol", protocol)

from liveware.wanxiang_auto_greeting import liveware_url_for_agent


class WanxiangGreetingUrlTests(unittest.TestCase):
    def test_result_path_is_bound_to_current_agent(self):
        agent_user_id = "usr_01ARZ3NDEKTSV4RRFFQ69G5FAV"
        url = liveware_url_for_agent(
            agent_user_id,
            "https://app-example.apps.clawling.io/?lang=zh-CN",
        )

        parts = urlsplit(url)
        self.assertEqual(parts.hostname, "app-example.apps.clawling.io")
        self.assertEqual(parse_qs(parts.query)["agent"], [agent_user_id])
        self.assertEqual(parse_qs(parts.query)["lang"], ["zh-CN"])

    def test_invalid_agent_never_creates_a_result_target(self):
        url = liveware_url_for_agent(
            "not-an-agent",
            "https://app-example.apps.clawling.io/",
        )
        self.assertNotIn("agent=", url)


if __name__ == "__main__":
    unittest.main()
