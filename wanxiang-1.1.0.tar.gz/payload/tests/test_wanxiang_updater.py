import base64
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from ops.wanxiang_updater import allowed_path, canonical_feed, verify_signature, version_tuple


class WanxiangUpdaterTests(unittest.TestCase):
    def test_semantic_versions(self):
        self.assertLess(version_tuple("1.2.3"), version_tuple("1.3.0"))
        with self.assertRaises(ValueError):
            version_tuple("1.2")

    def test_component_allowlist_and_private_exclusions(self):
        self.assertTrue(allowed_path("app/page.tsx", ["liveware-content"]))
        self.assertFalse(allowed_path("public/agent-avatar.png", ["liveware-content"]))
        self.assertTrue(allowed_path("public/agent-avatar.png", ["brand-profile"]))
        self.assertFalse(allowed_path("../../auth.json", ["operations"]))
        self.assertFalse(allowed_path("liveware/greeting.md", ["liveware-content"]))
        self.assertTrue(allowed_path("clone/release.json", ["liveware-content"]))
        self.assertTrue(allowed_path("clone/runtime-static/index.html", ["operations"]))

    def test_rsa_signature_verification(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            private, public, message, signature = base / "private.pem", base / "public.pem", base / "message", base / "signature"
            subprocess.run(["openssl", "genrsa", "-out", str(private), "2048"], check=True, capture_output=True)
            subprocess.run(["openssl", "rsa", "-in", str(private), "-pubout", "-out", str(public)], check=True, capture_output=True)
            feed = {"product": "wanxiang-jingting", "version": "1.1.0", "signature": "ignored"}
            payload = canonical_feed(feed)
            message.write_bytes(payload)
            subprocess.run(["openssl", "dgst", "-sha256", "-sign", str(private), "-out", str(signature), str(message)], check=True)
            verify_signature(payload, base64.b64encode(signature.read_bytes()).decode(), public)
            with self.assertRaises(RuntimeError):
                verify_signature(payload + b"x", base64.b64encode(signature.read_bytes()).decode(), public)


if __name__ == "__main__":
    unittest.main()
