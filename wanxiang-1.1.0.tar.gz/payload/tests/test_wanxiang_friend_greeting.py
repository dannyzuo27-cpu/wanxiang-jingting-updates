import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from ops import wanxiang_friend_greeting_daemon as daemon


class WanxiangFriendGreetingTests(unittest.TestCase):
    def test_claim_is_agent_scoped_and_reuses_pending_message_id(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            with patch.object(daemon, "STATE_DIR", base), patch.object(daemon, "DB", base / "greetings.sqlite3"):
                factory = lambda: "msg_fixed"
                self.assertEqual(daemon.claim("agent-a", "user-a", factory), "msg_fixed")
                self.assertEqual(daemon.claim("agent-a", "user-a", lambda: "msg_other"), "msg_fixed")
                daemon.mark_sent("agent-a", "user-a", "conversation-a")
                self.assertIsNone(daemon.claim("agent-a", "user-a", lambda: "msg_other"))
                self.assertEqual(daemon.claim("agent-b", "user-a", factory), "msg_fixed")


if __name__ == "__main__":
    unittest.main()
