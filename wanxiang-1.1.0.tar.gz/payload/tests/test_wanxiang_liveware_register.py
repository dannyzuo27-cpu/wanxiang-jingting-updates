import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from ops.wanxiang_liveware_register import RUNTIME_ROOT, app_url, brand_is_current, load_matching_state, parse_fields


class WanxiangLivewareRegisterTests(unittest.TestCase):
    def test_runtime_lives_in_clone_persistent_hermes_home(self):
        self.assertEqual(RUNTIME_ROOT, Path("/opt/data/wanxiang-runtime/site"))
    def test_parse_liveware_fields(self):
        fields = parse_fields("appId  app-example123\ninstanceId  agt_example\nname  万象镜厅\n")
        self.assertEqual(fields["appId"], "app-example123")
        self.assertEqual(fields["name"], "万象镜厅")

    def test_app_url_rejects_untrusted_ids(self):
        self.assertEqual(app_url("app-example123"), "https://app-example123.apps.clawling.io")
        with self.assertRaises(RuntimeError):
            app_url("https://example.com")

    def test_state_is_scoped_to_current_agent(self):
        with tempfile.TemporaryDirectory() as directory:
            state = Path(directory) / "registration.json"
            state.write_text(
                json.dumps(
                    {
                        "agent_id": "agt_AAAAAAAAAAAAAAAAAAAAAAAAAA",
                        "agent_user_id": "usr_BBBBBBBBBBBBBBBBBBBBBBBBBB",
                        "app_id": "app-example123",
                        "url": "https://app-example123.apps.clawling.io",
                    }
                )
            )
            with patch(
                "ops.wanxiang_liveware_register.inspect_owned_app",
                return_value={"appId": "app-example123"},
            ):
                self.assertIsNotNone(
                    load_matching_state(
                        "agt_AAAAAAAAAAAAAAAAAAAAAAAAAA",
                        "usr_BBBBBBBBBBBBBBBBBBBBBBBBBB",
                        state,
                    )
                )
                self.assertIsNone(
                    load_matching_state(
                        "agt_AAAAAAAAAAAAAAAAAAAAAAAAAA",
                        "usr_CCCCCCCCCCCCCCCCCCCCCCCCCC",
                        state,
                    )
                )

    def test_brand_state_is_versioned_and_agent_scoped(self):
        spec = {
            "brandVersion": 2,
            "nickname": "万象镜厅",
            "avatar_sha256": "a" * 64,
        }
        with tempfile.TemporaryDirectory() as directory:
            state = Path(directory) / "profile.json"
            state.write_text(
                json.dumps(
                    {
                        "agent_user_id": "usr_BBBBBBBBBBBBBBBBBBBBBBBBBB",
                        "brandVersion": 2,
                        "nickname": "万象镜厅",
                        "avatar_sha256": "a" * 64,
                        "avatar_url": "https://cdn.example/avatar.png",
                    }
                )
            )
            self.assertTrue(brand_is_current("usr_BBBBBBBBBBBBBBBBBBBBBBBBBB", spec, state))
            self.assertFalse(brand_is_current("usr_CCCCCCCCCCCCCCCCCCCCCCCCCC", spec, state))
            self.assertFalse(brand_is_current("usr_BBBBBBBBBBBBBBBBBBBBBBBBBB", {**spec, "brandVersion": 3}, state))


if __name__ == "__main__":
    unittest.main()
