#!/usr/bin/env python3
"""Model-free, per-Agent friend greeting service for cloned mirror halls."""

from __future__ import annotations

import argparse
import asyncio
import fcntl
import json
import sqlite3
import sys
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any

ROOT = Path("/opt/data/wanxiang-runtime/site")
STATE_DIR = ROOT / "state"
DB = STATE_DIR / "friend-greetings.sqlite3"
MARKER = STATE_DIR / "migrate-legacy-for-agent"
LEGACY_DB = Path("/opt/data/clawchat/wanxiang_auto_greeting.sqlite3")
REGISTRATION = Path("/opt/data/wanxiang-liveware/registration.json")
CONFIG = Path("/opt/data/config.yaml")
PLUGIN = Path("/opt/data/plugins/clawchat")


def identity() -> tuple[str, str, str]:
    import yaml

    data = yaml.safe_load(CONFIG.read_text(encoding="utf-8")) or {}
    extra = (((data.get("platforms") or {}).get("clawchat") or {}).get("extra") or {})
    return (
        str(extra.get("agent_id") or ""),
        str(extra.get("user_id") or ""),
        str(extra.get("owner_user_id") or ""),
    )


def connect() -> sqlite3.Connection:
    STATE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    connection = sqlite3.connect(DB, timeout=10)
    connection.execute(
        """CREATE TABLE IF NOT EXISTS greetings (
        agent_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        conversation_id TEXT,
        status TEXT NOT NULL,
        sent_at INTEGER,
        PRIMARY KEY(agent_id, user_id)
        )"""
    )
    return connection


def seed_legacy(agent_id: str) -> None:
    try:
        allowed = MARKER.read_text(encoding="utf-8").strip() == agent_id
    except OSError:
        allowed = False
    if not allowed or not LEGACY_DB.is_file():
        return
    try:
        legacy = sqlite3.connect(LEGACY_DB)
        rows = legacy.execute(
            "SELECT user_id, conversation_id, sent_at FROM friend_greetings WHERE status = 'sent'"
        ).fetchall()
        legacy.close()
        with connect() as current:
            current.executemany(
                "INSERT OR IGNORE INTO greetings(agent_id,user_id,conversation_id,status,sent_at) VALUES(?,?,?,'sent',?)",
                [(agent_id, str(user_id), conversation_id, sent_at) for user_id, conversation_id, sent_at in rows],
            )
    finally:
        MARKER.unlink(missing_ok=True)


def sent(agent_id: str, user_id: str) -> bool:
    with connect() as connection:
        row = connection.execute(
            "SELECT status FROM greetings WHERE agent_id=? AND user_id=?",
            (agent_id, user_id),
        ).fetchone()
    return bool(row and row[0] == "sent")


def mark_sent(agent_id: str, user_id: str, conversation_id: str) -> None:
    with connect() as connection:
        connection.execute(
            "INSERT OR REPLACE INTO greetings(agent_id,user_id,conversation_id,status,sent_at) VALUES(?,?,?,'sent',?)",
            (agent_id, user_id, conversation_id, int(time.time())),
        )


def rows(data: Any, key: str) -> list[dict[str, Any]]:
    values = data.get(key) if isinstance(data, dict) else []
    return [item for item in values if isinstance(item, dict)] if isinstance(values, list) else []


def friend_id(item: dict[str, Any]) -> str:
    nested = item.get("user") if isinstance(item.get("user"), dict) else {}
    return str(nested.get("id") or item.get("user_id") or item.get("userId") or item.get("id") or "")


def conversation_for(data: Any, user_id: str) -> str:
    for item in rows(data, "conversations"):
        if item.get("type") not in {"direct", "dm"}:
            continue
        peer = item.get("peer") if isinstance(item.get("peer"), dict) else {}
        if str(peer.get("id") or item.get("peer_id") or "") == user_id:
            return str(item.get("id") or "")
    return ""


async def poll_once() -> None:
    sys.path.insert(0, str(PLUGIN))
    sys.path.insert(0, str(ROOT))
    from clawchat_gateway.standalone_send import standalone_send
    from clawchat_gateway.tools import _build_client
    from liveware.wanxiang_auto_greeting import GREETING_TEXT, liveware_url_for_agent

    agent_id, agent_user_id, owner_user_id = identity()
    registration = json.loads(REGISTRATION.read_text(encoding="utf-8"))
    if registration.get("agent_id") != agent_id or registration.get("agent_user_id") != agent_user_id:
        return
    url = liveware_url_for_agent(agent_user_id, registration.get("url"))
    if not url:
        return
    client, error = _build_client()
    if client is None or error:
        return
    friends = await client.list_friends(page=1, page_size=100)
    conversations = await client._call_json("GET", "/v1/conversations?limit=100")
    for item in rows(friends, "friends"):
        user_id = friend_id(item)
        if not user_id or user_id in {owner_user_id, agent_user_id} or sent(agent_id, user_id):
            continue
        conversation_id = conversation_for(conversations, user_id)
        if not conversation_id:
            continue
        result = await standalone_send(
            SimpleNamespace(extra={}),
            conversation_id,
            GREETING_TEXT.format(url=url),
        )
        if isinstance(result, dict) and result.get("success") is True:
            mark_sent(agent_id, user_id, conversation_id)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--interval", type=int, default=30)
    args = parser.parse_args()
    STATE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    lock = (STATE_DIR / "friend-greeting.lock").open("w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        return 0
    agent_id, _, _ = identity()
    seed_legacy(agent_id)
    while True:
        try:
            asyncio.run(poll_once())
        except Exception as exc:
            print(f"friend greeting poll failed: {exc}", flush=True)
        time.sleep(max(15, args.interval))


if __name__ == "__main__":
    raise SystemExit(main())
