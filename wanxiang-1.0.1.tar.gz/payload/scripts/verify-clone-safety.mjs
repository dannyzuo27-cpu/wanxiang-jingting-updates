import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const release = JSON.parse(await readFile(new URL("clone/release.json", root), "utf8"));
const files = [
  ...release.managedFiles,
  "app/page.tsx",
  "clone/listing-description.md",
  "clone/CLONE_SAFETY.md",
];

const forbidden = [
  { name: "fixed ClawChat user ID", pattern: /usr_[0-9A-HJKMNP-TV-Z]{26}/g },
  { name: "creator Liveware app ID", pattern: /app-1bdb629a56d0a285/g },
  { name: "creator home path", pattern: /\/Users\/newbasedanny(?:\/|\b)/g },
  { name: "SSH forwarding host", pattern: /forward\.agent-dashboard\.clawling\.io/g },
  { name: "private key material", pattern: /-----BEGIN (?:OPENSSH|RSA|EC|PRIVATE) PRIVATE KEY-----/g },
  { name: "literal bearer token", pattern: /Authorization\s*:\s*Bearer\s+[A-Za-z0-9._~-]{16,}/gi },
];

for (const file of files) {
  const source = await readFile(new URL(file, root), "utf8");
  for (const rule of forbidden) {
    assert.doesNotMatch(source, rule.pattern, `${file} contains ${rule.name}`);
  }
}

const page = await readFile(new URL("app/page.tsx", root), "utf8");
assert.match(page, /URLSearchParams\(window\.location\.search\)\.get\("agent"\)/, "Liveware must receive the current clone identity at runtime");
assert.match(page, /CLAWCHAT_USER_ID_PATTERN\.test/, "runtime Agent IDs must be validated");
assert.match(page, /if \(!agentUserId\) return null/, "sharing must fail closed when no Agent identity is present");

console.log(`Clone safety verified across ${files.length} public files.`);
