from __future__ import annotations

import os
import json
import re
import shutil
import sqlite3
import subprocess
import time
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from clawchat_gateway.protocol import new_message_id


LIVEWARE_APP_NAMES = ("万象镜厅", "十四面镜")
LIVEWARE_CLI = "/opt/clawnest/bin/liveware"
LIVEWARE_REGISTRATION_STATE = Path("/opt/data/wanxiang-liveware/registration.json")

SUPPORTED_LOCALES = ("en", "zh-CN", "zh-TW", "ja", "es", "ko")

_GREETINGS = {
    "en": """Welcome to the Hall of Myriad Mirrors.

The first chamber, “The Fourteen-Faceted Mirror,” is open—a Seven Deadly Sins × Seven Virtues personality test. Tap the card below to begin the 35 questions:

{url}""",
    "zh-CN": """欢迎来到万象镜厅。

第一镜室「十四面镜」已经开启——这是一场七宗罪 × 七美德人格测试。点击下方卡片，开始 35 道镜问：

{url}""",
    "zh-TW": """歡迎來到萬象鏡廳。

第一鏡室「十四面鏡」已經開啟——這是一場七宗罪 × 七美德人格測試。點擊下方卡片，開始 35 道鏡問：

{url}""",
    "ja": """万象鏡庁へようこそ。

第一鏡室「十四面鏡」が開きました。七つの大罪 × 七つの美徳を映す性格テストです。下のカードをタップして、35の問いを始めてください：

{url}""",
    "es": """Te damos la bienvenida al Salón de los Mil Espejos.

La primera sala, «El espejo de catorce caras», ya está abierta: una prueba de personalidad sobre los siete pecados capitales y las siete virtudes. Toca la tarjeta de abajo para comenzar las 35 preguntas:

{url}""",
    "ko": """만상경청에 오신 것을 환영합니다.

첫 번째 거울방 ‘십사면경’이 열렸습니다. 7대 죄악 × 7가지 미덕 성격 테스트입니다. 아래 카드를 눌러 35개 문항을 시작하세요:

{url}""",
}

GREETING_TEXT = """Welcome · 欢迎 · 歡迎 · ようこそ · Bienvenido/a · 환영합니다

万象镜厅
第一镜室 · 十四面镜
七宗罪 × 七美德人格测试
照见你的阴影，也照见你的光。
点击下方卡片，进入镜室。

𝑯𝒂𝒍𝒍 𝒐𝒇 𝑴𝒚𝒓𝒊𝒂𝒅 𝑴𝒊𝒓𝒓𝒐𝒓𝒔
𝑪𝒉𝒂𝒎𝒃𝒆𝒓 𝑰 · 𝑻𝒉𝒆 𝑭𝒐𝒖𝒓𝒕𝒆𝒆𝒏 𝑴𝒊𝒓𝒓𝒐𝒓𝒔
𝑺𝒆𝒗𝒆𝒏 𝑺𝒊𝒏𝒔 × 𝑺𝒆𝒗𝒆𝒏 𝑽𝒊𝒓𝒕𝒖𝒆𝒔
𝑺𝒆𝒆 𝒚𝒐𝒖𝒓 𝒔𝒉𝒂𝒅𝒐𝒘. 𝑺𝒆𝒆 𝒚𝒐𝒖𝒓 𝒍𝒊𝒈𝒉𝒕.
𝑬𝒏𝒕𝒆𝒓 𝒕𝒉𝒓𝒐𝒖𝒈𝒉 𝒕𝒉𝒆 𝒄𝒂𝒓𝒅 𝒃𝒆𝒍𝒐𝒘.

{url}"""

_USER_ID_RE = re.compile(r"^usr_[0-9A-HJKMNP-TV-Z]{26}$")
_LIVEWARE_DOMAIN_RE = re.compile(r"\b(app-[a-z0-9]+\.apps\.clawling\.io)\b", re.IGNORECASE)
_liveware_url_cache: tuple[float, str] = (0.0, "")


@dataclass(frozen=True)
class GreetingClaim:
    user_id: str
    message_id: str


class AutoGreetingState:
    """Durable exactly-once state for proactive friend greetings."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        try:
            os.chmod(self.db_path.parent, 0o700)
        except OSError:
            pass
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS friend_greetings (
                    user_id TEXT PRIMARY KEY,
                    message_id TEXT NOT NULL UNIQUE,
                    status TEXT NOT NULL CHECK(status IN ('pending', 'sent')),
                    conversation_id TEXT,
                    created_at INTEGER NOT NULL,
                    sent_at INTEGER
                )
                """
            )
        try:
            os.chmod(self.db_path, 0o600)
        except OSError:
            pass

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path, timeout=10)

    def claim(self, user_id: str) -> GreetingClaim | None:
        if not is_valid_user_id(user_id):
            return None
        now = int(time.time() * 1000)
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT message_id, status FROM friend_greetings WHERE user_id = ?",
                (user_id,),
            ).fetchone()
            if row is not None:
                message_id, status = row
                if status == "sent":
                    return None
                return GreetingClaim(user_id=user_id, message_id=str(message_id))
            message_id = new_message_id()
            conn.execute(
                "INSERT INTO friend_greetings (user_id, message_id, status, created_at) VALUES (?, ?, 'pending', ?)",
                (user_id, message_id, now),
            )
            return GreetingClaim(user_id=user_id, message_id=message_id)

    def mark_sent(self, claim: GreetingClaim, conversation_id: str) -> bool:
        now = int(time.time() * 1000)
        with self._connect() as conn:
            cursor = conn.execute(
                """
                UPDATE friend_greetings
                SET status = 'sent', conversation_id = ?, sent_at = ?
                WHERE user_id = ? AND message_id = ? AND status = 'pending'
                """,
                (conversation_id, now, claim.user_id, claim.message_id),
            )
            return cursor.rowcount == 1

    def pending_user_ids(self, *, limit: int = 100) -> list[str]:
        safe_limit = max(1, min(int(limit), 100))
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT user_id FROM friend_greetings WHERE status = 'pending' ORDER BY created_at ASC LIMIT ?",
                (safe_limit,),
            ).fetchall()
        return [str(row[0]) for row in rows if is_valid_user_id(str(row[0]))]


def is_valid_user_id(user_id: str) -> bool:
    return bool(_USER_ID_RE.fullmatch(user_id))


def normalize_supported_locale(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    token = value.strip().replace("_", "-").lower()
    if not token:
        return None
    if token in {"zh-tw", "zh-hant", "zh-hk", "zh-mo"}:
        return "zh-TW"
    if token in {"zh", "zh-cn", "zh-hans", "zh-sg"}:
        return "zh-CN"
    language = token.split("-", 1)[0]
    return language if language in {"en", "ja", "es", "ko"} else None


def locale_from_profile(data: dict[str, Any]) -> str | None:
    if not isinstance(data, dict):
        return None
    detail = data.get("user") if isinstance(data.get("user"), dict) else data
    for key in ("locale", "language", "preferred_language", "preferredLanguage"):
        locale = normalize_supported_locale(detail.get(key))
        if locale:
            return locale
    return None


def _trusted_liveware_url(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        return ""
    parts = urlsplit(value.strip())
    if parts.scheme != "https" or not parts.hostname or not parts.hostname.endswith(".apps.clawling.io"):
        return ""
    return urlunsplit(("https", parts.netloc, parts.path.rstrip("/"), parts.query, parts.fragment))


def _registered_liveware_url(agent_user_id: Any) -> str:
    """Read only a registration explicitly bound to this Agent's user id."""
    if not isinstance(agent_user_id, str) or not is_valid_user_id(agent_user_id):
        return ""
    try:
        data = json.loads(LIVEWARE_REGISTRATION_STATE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ""
    if data.get("agent_user_id") != agent_user_id:
        return ""
    app_id = str(data.get("app_id") or "")
    url = _trusted_liveware_url(data.get("url"))
    parts = urlsplit(url) if url else None
    if not app_id or parts is None or parts.hostname != f"{app_id}.apps.clawling.io":
        return ""
    return url


def discover_liveware_url(agent_user_id: Any = None) -> str:
    """Resolve this clone's own Liveware app; never inherit the creator's app ID."""
    global _liveware_url_cache
    registered = _registered_liveware_url(agent_user_id)
    if registered:
        return registered
    # An environment URL can be copied into a clone, so it is deliberately not
    # trusted.  Before the startup registrar creates an Agent-bound state file,
    # fail closed instead of guessing from another instance's app list.
    if agent_user_id is not None:
        return ""
    cached_at, cached_url = _liveware_url_cache
    if cached_url and time.monotonic() - cached_at < 300:
        return cached_url
    cli = shutil.which("liveware") or LIVEWARE_CLI
    try:
        result = subprocess.run(
            [cli, "app", "list"],
            check=True,
            capture_output=True,
            text=True,
            timeout=8,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    for line in result.stdout.splitlines():
        if not any(name in line for name in LIVEWARE_APP_NAMES):
            continue
        match = _LIVEWARE_DOMAIN_RE.search(line)
        if not match:
            continue
        resolved = _trusted_liveware_url(f"https://{match.group(1).lower()}")
        if resolved:
            _liveware_url_cache = (time.monotonic(), resolved)
            return resolved
    return ""


def liveware_url_for_agent(agent_user_id: Any, base_url: Any = None) -> str:
    """Bind result sharing to the clone that issued the card, never to its creator."""
    resolved = _trusted_liveware_url(base_url) or discover_liveware_url(agent_user_id)
    if not resolved:
        return ""
    if not isinstance(agent_user_id, str) or not is_valid_user_id(agent_user_id):
        return resolved
    parts = urlsplit(resolved)
    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    query["agent"] = agent_user_id
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def greeting_for_locale(locale: Any, agent_user_id: Any = None) -> str:
    normalized = normalize_supported_locale(locale)
    template = _GREETINGS.get(normalized) if normalized else None
    url = liveware_url_for_agent(agent_user_id)
    if not url:
        raise RuntimeError("this Agent has no Wanxiang Liveware app configured")
    return (template or GREETING_TEXT).format(url=url)


def find_direct_conversation(data: dict[str, Any], user_id: str) -> str | None:
    rows = data.get("conversations")
    if not isinstance(rows, list):
        rows = data.get("items")
    if not isinstance(rows, list):
        return None
    for row in rows:
        if not isinstance(row, dict) or row.get("type") not in {"direct", "dm"}:
            continue
        peer = row.get("peer")
        peer_id = peer.get("id") if isinstance(peer, dict) else row.get("peer_id")
        if peer_id != user_id:
            continue
        conversation_id = row.get("id")
        if isinstance(conversation_id, str) and conversation_id.startswith("cnv_"):
            return conversation_id
    return None


def friend_user_ids(data: dict[str, Any]) -> list[str]:
    rows = next(
        (data.get(key) for key in ("friends", "items", "users", "records") if isinstance(data.get(key), list)),
        [],
    )
    result: list[str] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        nested = row.get("user")
        user_id = (
            nested.get("id") if isinstance(nested, dict) else None
        ) or row.get("user_id") or row.get("userId") or row.get("id")
        if isinstance(user_id, str) and is_valid_user_id(user_id):
            result.append(user_id)
    return list(dict.fromkeys(result))
