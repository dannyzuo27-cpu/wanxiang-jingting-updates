import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const release = JSON.parse(await readFile(new URL("clone/release.json", root), "utf8"));
const files = [
  ...release.managedFiles,
  "app/page.tsx",
  "clone/listing-description.md",
  "clone/CLONE_SAFETY.md",
  "liveware/CLONE_WELCOME_CHAIN.md",
  "liveware/FRIEND_WELCOME_CHAIN.md",
];

const forbidden = [
  { name: "fixed ClawChat user ID", pattern: /usr_[0-9A-HJKMNP-TV-Z]{26}/g },
  { name: "creator Liveware app ID", pattern: /app-1bdb629a56d0a285/g },
  { name: "creator home path", pattern: /\/Users\/newbasedanny(?:\/|\b)/g },
  { name: "SSH forwarding host", pattern: /forward\.agent-dashboard\.clawling\.io/g },
  { name: "private key material", pattern: /-----BEGIN (?:OPENSSH|RSA|EC|PRIVATE) PRIVATE KEY-----/g },
  { name: "literal bearer token", pattern: /Authorization\s*:\s*Bearer\s+[A-Za-z0-9._~-]{16,}/gi },
];

for (const file of files) {
  const source = await readFile(new URL(file, root), "utf8");
  for (const rule of forbidden) {
    assert.doesNotMatch(source, rule.pattern, `${file} contains ${rule.name}`);
  }
}

const page = await readFile(new URL("app/page.tsx", root), "utf8");
assert.match(page, /URLSearchParams\(window\.location\.search\)\.get\("agent"\)/, "Liveware must receive the current clone identity at runtime");
assert.match(page, /CLAWCHAT_USER_ID_PATTERN\.test/, "runtime Agent IDs must be validated");
assert.match(page, /if \(!agentUserId\) return null/, "sharing must fail closed when no Agent identity is present");

const greeting = await readFile(new URL("liveware/greeting.md", root), "utf8");
assert.match(greeting, /两条彼此独立的链路/, "clone-owner and friend greetings must remain separate");
assert.match(greeting, /新 Agent 被克隆并完成激活后/, "new clone owners must receive an activation greeting");

const registrar = await readFile(new URL("ops/wanxiang_liveware_register.py", root), "utf8");
assert.match(registrar, /fields\.get\("instanceId"\) != agent_id/, "startup registration must reject another Agent's Liveware");
assert.match(registrar, /\/opt\/data\/workspace\/wanxiang-jingting-site/, "Liveware code must use the fixed persistent instance path");
assert.match(registrar, /tools\.register_app\(APP_NAME, app_id, url\)/, "startup registration must refresh the current Agent's app card");

console.log(`Clone safety verified across ${files.length} public files.`);
