#!/usr/bin/env python3
"""Signed, model-free updater for independent Wanxiang Jingting clones."""

from __future__ import annotations

import argparse
import base64
import fcntl
import hashlib
import json
import os
import shutil
import signal
import subprocess
import tarfile
import tempfile
import time
import urllib.request
from pathlib import Path, PurePosixPath
from typing import Any

PRODUCT = "wanxiang-jingting"
DEFAULT_ROOT = Path("/opt/data/workspace/wanxiang-jingting-site")
DEFAULT_STATE_DIR = Path("/opt/data/wanxiang-update")
MAX_DOWNLOAD_BYTES = 100 * 1024 * 1024
COMPONENT_PATHS: dict[str, tuple[str, ...]] = {
    "liveware-content": ("app/", "public/", "package.json", "package-lock.json", "tests/"),
    "agent-reading": ("liveware/SOUL.md", "liveware/skills/wanxiang-jingting/"),
    "friend-welcome": (
        "liveware/greeting.md",
        "liveware/FRIEND_WELCOME_CHAIN.md",
        "liveware/CLONE_WELCOME_CHAIN.md",
        "liveware/wanxiang_auto_greeting.py",
        "clone/hotfixes/clawchat-adapter-current-agent.patch",
    ),
    "operations": ("ops/", "scripts/verify-clone-safety.mjs", "clone/", "public/wanxiang-release.json"),
}
NEVER_UPDATE = {
    "public/agent-avatar.png",
    ".openai/hosting.json",
    ".env",
}
VERSION_METADATA = {"clone/release.json", "public/wanxiang-release.json"}


def canonical_feed(feed: dict[str, Any]) -> bytes:
    unsigned = {key: value for key, value in feed.items() if key != "signature"}
    return json.dumps(unsigned, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def version_tuple(value: str) -> tuple[int, int, int]:
    parts = value.split(".")
    if len(parts) != 3 or any(not part.isdigit() for part in parts):
        raise ValueError(f"invalid semantic version: {value}")
    return tuple(int(part) for part in parts)  # type: ignore[return-value]


def allowed_path(path: str, components: list[str]) -> bool:
    pure = PurePosixPath(path)
    if pure.is_absolute() or ".." in pure.parts or not path or path in NEVER_UPDATE:
        return False
    if path in VERSION_METADATA:
        return True
    allowed = tuple(prefix for component in components for prefix in COMPONENT_PATHS.get(component, ()))
    return any(path == prefix or (prefix.endswith("/") and path.startswith(prefix)) for prefix in allowed)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download(url: str, destination: Path) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": "wanxiang-updater/1"})
    with urllib.request.urlopen(request, timeout=30) as response, destination.open("wb") as output:
        total = 0
        while chunk := response.read(1024 * 1024):
            total += len(chunk)
            if total > MAX_DOWNLOAD_BYTES:
                raise RuntimeError("update exceeds size limit")
            output.write(chunk)


def verify_signature(payload: bytes, signature_b64: str, public_key: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="wanxiang-signature-") as directory:
        base = Path(directory)
        payload_file = base / "payload.json"
        signature_file = base / "signature.bin"
        payload_file.write_bytes(payload)
        signature_file.write_bytes(base64.b64decode(signature_b64, validate=True))
        result = subprocess.run(
            ["openssl", "dgst", "-sha256", "-verify", str(public_key), "-signature", str(signature_file), str(payload_file)],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError("update signature is invalid")


def load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"expected object in {path}")
    return data


def extract_verified(package: Path, destination: Path) -> tuple[dict[str, Any], list[str]]:
    with tarfile.open(package, "r:gz") as archive:
        members = archive.getmembers()
        if any(member.issym() or member.islnk() or member.name.startswith("/") or ".." in PurePosixPath(member.name).parts for member in members):
            raise RuntimeError("unsafe update archive")
        manifest_member = archive.getmember("update-manifest.json")
        manifest = json.loads(archive.extractfile(manifest_member).read())  # type: ignore[union-attr]
        if manifest.get("product") != PRODUCT:
            raise RuntimeError("wrong update product")
        components = manifest.get("components")
        files = manifest.get("files")
        if not isinstance(components, list) or not isinstance(files, list):
            raise RuntimeError("invalid update manifest")
        expected: list[str] = []
        for item in files:
            path = item.get("path") if isinstance(item, dict) else None
            digest = item.get("sha256") if isinstance(item, dict) else None
            if not isinstance(path, str) or not isinstance(digest, str) or not allowed_path(path, components):
                raise RuntimeError(f"forbidden update path: {path}")
            member = archive.getmember(f"payload/{path}")
            source = archive.extractfile(member)
            if source is None:
                raise RuntimeError(f"missing payload: {path}")
            target = destination / path
            target.parent.mkdir(parents=True, exist_ok=True)
            content = source.read()
            if hashlib.sha256(content).hexdigest() != digest:
                raise RuntimeError(f"payload checksum mismatch: {path}")
            target.write_bytes(content)
            expected.append(path)
        payload_members = {member.name.removeprefix("payload/") for member in members if member.isfile() and member.name.startswith("payload/")}
        if payload_members != set(expected):
            raise RuntimeError("archive contains undeclared payload files")
        return manifest, expected


def backup_files(root: Path, paths: list[str], backup: Path) -> None:
    with tarfile.open(backup, "w:gz") as archive:
        for relative in paths:
            source = root / relative
            if source.exists():
                archive.add(source, arcname=relative, recursive=False)


def restore_backup(root: Path, backup: Path, paths: list[str]) -> None:
    for relative in paths:
        target = root / relative
        if target.is_file():
            target.unlink()
    with tarfile.open(backup, "r:gz") as archive:
        archive.extractall(root)


def copy_payload(staging: Path, root: Path, paths: list[str]) -> None:
    for relative in paths:
        source, target = staging / relative, root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def run_checked(command: list[str], cwd: Path) -> None:
    subprocess.run(command, cwd=cwd, check=True, timeout=600)


def install_active_files(root: Path, components: list[str]) -> None:
    if not str(root).startswith("/opt/data/"):
        return
    if "agent-reading" in components:
        shutil.copy2(root / "liveware/SOUL.md", "/opt/data/SOUL.md")
        skill_dir = Path("/opt/data/skills/wanxiang-jingting")
        skill_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / "liveware/skills/wanxiang-jingting/SKILL.md", skill_dir / "SKILL.md")
    if "friend-welcome" in components:
        shutil.copy2(root / "liveware/greeting.md", "/opt/data/clawchat/greeting.md")
        plugin = Path("/opt/data/plugins/clawchat")
        shutil.copy2(root / "liveware/wanxiang_auto_greeting.py", plugin / "clawchat_gateway/wanxiang_auto_greeting.py")
        adapter = plugin / "clawchat_gateway/adapter.py"
        desired = "greeting_for_locale(locale, self._clawchat_config.user_id)"
        if desired not in adapter.read_text(encoding="utf-8"):
            run_checked(["patch", "-p1", "--forward", "-i", str(root / "clone/hotfixes/clawchat-adapter-current-agent.patch")], plugin)
    if "operations" in components:
        supervisor = Path("/opt/data/.clawling/supervisord")
        supervisor.mkdir(parents=True, exist_ok=True)
        shutil.copy2(
            root / "ops/wanxiang-liveware-register.conf",
            supervisor / "wanxiang-liveware-register.conf",
        )


def restart_services(components: list[str]) -> None:
    needles = ["vinext start"] if "liveware-content" in components else []
    if any(component in components for component in ("agent-reading", "friend-welcome")):
        needles.append("/opt/hermes/.venv/bin/hermes gateway run")
    for proc in Path("/proc").glob("[0-9]*/cmdline"):
        try:
            command = proc.read_bytes().replace(b"\0", b" ").decode(errors="ignore")
        except OSError:
            continue
        if any(needle in command for needle in needles):
            os.kill(int(proc.parent.name), signal.SIGTERM)


def apply_update(root: Path, state_dir: Path, feed: dict[str, Any], package: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="wanxiang-update-stage-") as directory:
        staging = Path(directory)
        manifest, paths = extract_verified(package, staging)
        if manifest.get("version") != feed.get("version") or manifest.get("components") != feed.get("components"):
            raise RuntimeError("feed and package metadata differ")
        backups = state_dir / "backups"
        backups.mkdir(parents=True, exist_ok=True)
        backup = backups / f"before-{feed['version']}-{int(time.time())}.tar.gz"
        backup_files(root, paths, backup)
        try:
            copy_payload(staging, root, paths)
            components = feed["components"]
            run_checked(["node", "scripts/verify-clone-safety.mjs"], root)
            if "liveware-content" in components:
                run_checked(["npm", "install", "--ignore-scripts"], root)
                run_checked(["npm", "run", "build"], root)
            install_active_files(root, components)
            restart_services(components)
        except Exception:
            restore_backup(root, backup, paths)
            if "liveware-content" in feed.get("components", []):
                subprocess.run(["npm", "run", "build"], cwd=root, timeout=600)
            raise


def check_once(root: Path, state_dir: Path, public_key: Path) -> str:
    config = load_json(state_dir / "config.json")
    feed_url = config.get("feed_url")
    if not isinstance(feed_url, str) or not feed_url.startswith("https://"):
        return "disabled: no HTTPS feed configured"
    state_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="wanxiang-update-download-") as directory:
        base = Path(directory)
        feed_path, package_path = base / "feed.json", base / "package.tar.gz"
        download(feed_url, feed_path)
        feed = load_json(feed_path)
        if feed.get("product") != PRODUCT or feed.get("channel") != config.get("channel", "stable"):
            raise RuntimeError("wrong update feed")
        verify_signature(canonical_feed(feed), str(feed.get("signature", "")), public_key)
        installed = load_json(root / "clone/release.json").get("version", "0.0.0")
        if version_tuple(str(feed["version"])) <= version_tuple(str(installed)):
            return f"current: {installed}"
        if not config.get("auto_update", False):
            return f"available: {feed['version']} (auto update disabled)"
        package_url = feed.get("package_url")
        if not isinstance(package_url, str) or not package_url.startswith("https://"):
            raise RuntimeError("invalid package URL")
        download(package_url, package_path)
        if sha256_file(package_path) != feed.get("package_sha256"):
            raise RuntimeError("package checksum mismatch")
        apply_update(root, state_dir, feed, package_path)
        return f"updated: {installed} -> {feed['version']}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--daemon", action="store_true")
    parser.add_argument("--root", type=Path, default=Path(os.environ.get("WANXIANG_ROOT", DEFAULT_ROOT)))
    parser.add_argument("--state-dir", type=Path, default=Path(os.environ.get("WANXIANG_UPDATE_STATE", DEFAULT_STATE_DIR)))
    args = parser.parse_args()
    args.state_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    lock = (args.state_dir / "updater.lock").open("w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        return 0
    public_key = args.root / "clone/keys/wanxiang-update-public.pem"
    interval = 86400
    while True:
        try:
            message = check_once(args.root, args.state_dir, public_key)
            print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}", flush=True)
        except FileNotFoundError as exc:
            print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] disabled: {exc}", flush=True)
        except Exception as exc:
            print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] update failed: {exc}", flush=True)
        if not args.daemon:
            return 0
        try:
            config = load_json(args.state_dir / "config.json")
            interval = max(900, int(config.get("interval_seconds", interval)))
        except Exception:
            pass
        time.sleep(interval)


if __name__ == "__main__":
    raise SystemExit(main())
