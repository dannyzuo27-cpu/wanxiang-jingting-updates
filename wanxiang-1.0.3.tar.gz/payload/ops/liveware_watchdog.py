#!/usr/bin/env python3
"""Health watchdog for the 万象镜厅 Liveware service."""

from __future__ import annotations

import datetime as dt
import subprocess
import time
import urllib.error
import urllib.request


HEALTH_URL = "http://127.0.0.1:3100/"
EXPECTED_TEXT = "万象镜厅"
CHECK_INTERVAL_SECONDS = 30
FAILURES_BEFORE_RESTART = 3
REQUEST_TIMEOUT_SECONDS = 8
HEARTBEAT_EVERY_CHECKS = 20
RESTART_COMMAND = (
    "/usr/local/bin/supervisord",
    "ctl",
    "-c",
    "/etc/supervisor/supervisord.conf",
    "restart",
    "wanxiang-liveware",
)


def log(message: str) -> None:
    timestamp = dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")
    print(f"{timestamp} {message}", flush=True)


def check_health() -> tuple[bool, str]:
    request = urllib.request.Request(
        HEALTH_URL,
        headers={"User-Agent": "wanxiang-liveware-watchdog/1.0"},
    )
    try:
        with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
            status = response.status
            body = response.read(512_000).decode("utf-8", errors="replace")
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return False, f"request_error={type(exc).__name__}:{exc}"

    if status != 200:
        return False, f"http_status={status}"
    if EXPECTED_TEXT not in body:
        return False, "expected_content_missing"
    return True, "http_status=200 content=ok"


def restart_liveware() -> bool:
    try:
        completed = subprocess.run(
            RESTART_COMMAND,
            check=False,
            capture_output=True,
            text=True,
            timeout=45,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        log(f"RESTART_FAILED error={type(exc).__name__}:{exc}")
        return False

    details = (completed.stdout or completed.stderr).strip().replace("\n", " | ")
    if completed.returncode == 0:
        log(f"RESTART_REQUESTED result={details or 'ok'}")
        return True
    log(f"RESTART_FAILED exit={completed.returncode} result={details or '-'}")
    return False


def main() -> None:
    consecutive_failures = 0
    healthy_checks = 0
    was_unhealthy = False
    log(
        "WATCHDOG_STARTED "
        f"url={HEALTH_URL} interval={CHECK_INTERVAL_SECONDS}s "
        f"failure_threshold={FAILURES_BEFORE_RESTART}"
    )

    while True:
        healthy, detail = check_health()
        if healthy:
            if was_unhealthy:
                log(f"LIVEWARE_RECOVERED {detail}")
            consecutive_failures = 0
            was_unhealthy = False
            healthy_checks += 1
            if healthy_checks % HEARTBEAT_EVERY_CHECKS == 0:
                log(f"HEALTHY {detail}")
        else:
            was_unhealthy = True
            consecutive_failures += 1
            log(
                "HEALTH_CHECK_FAILED "
                f"attempt={consecutive_failures}/{FAILURES_BEFORE_RESTART} {detail}"
            )
            if consecutive_failures >= FAILURES_BEFORE_RESTART:
                restart_liveware()
                consecutive_failures = 0

        time.sleep(CHECK_INTERVAL_SECONDS)


if __name__ == "__main__":
    main()
