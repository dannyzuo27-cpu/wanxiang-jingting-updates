#!/usr/bin/env python3
"""Register this instance's Wanxiang Liveware on every container start.

The hook is intentionally model-free.  It rejects registrations inherited
from another Agent, reuses an app only when ``liveware app inspect`` proves
that the app belongs to the current Agent instance, and persists only the
current instance's public registration tuple.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from typing import Any

APP_NAME = "万象镜厅"
LEGACY_APP_NAMES = {"万象镜厅", "十四面镜"}
ROOT = Path("/opt/data/workspace/wanxiang-jingting-site")
CONFIG = Path("/opt/data/config.yaml")
STATE = Path("/opt/data/wanxiang-liveware/registration.json")
LIVEWARE = Path("/opt/clawnest/bin/liveware")
PLUGIN = Path("/opt/data/plugins/clawchat")
DEFAULT_PORT = 3100
APP_ID_RE = re.compile(r"^app-[a-z0-9]+$")
USER_ID_RE = re.compile(r"^usr_[0-9A-HJKMNP-TV-Z]{26}$")
AGENT_ID_RE = re.compile(r"^agt_[0-9A-HJKMNP-TV-Z]{26}$")
URL_RE = re.compile(r"^https://(app-[a-z0-9]+)\.apps\.clawling\.io/?$")


def run_liveware(*args: str, timeout: int = 30) -> str:
    result = subprocess.run(
        [str(LIVEWARE), *args],
        check=True,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return result.stdout


def parse_fields(output: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    for raw in output.splitlines():
        line = raw.strip()
        if not line:
            continue
        parts = line.split(None, 1)
        if len(parts) == 2:
            fields[parts[0]] = parts[1].strip()
    return fields


def load_identity(config_path: Path = CONFIG) -> tuple[str, str]:
    import yaml

    data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    extra = (((data.get("platforms") or {}).get("clawchat") or {}).get("extra") or {})
    agent_id = str(extra.get("agent_id") or "")
    user_id = str(extra.get("user_id") or "")
    if not AGENT_ID_RE.fullmatch(agent_id) or not USER_ID_RE.fullmatch(user_id):
        raise RuntimeError("current ClawChat Agent identity is unavailable")
    return agent_id, user_id


def app_url(app_id: str) -> str:
    if not APP_ID_RE.fullmatch(app_id):
        raise RuntimeError("invalid Liveware app id")
    return f"https://{app_id}.apps.clawling.io"


def inspect_owned_app(app_id: str, agent_id: str) -> dict[str, str] | None:
    if not APP_ID_RE.fullmatch(app_id):
        return None
    try:
        fields = parse_fields(run_liveware("app", "inspect", app_id))
    except (OSError, subprocess.SubprocessError):
        return None
    if fields.get("appId") != app_id or fields.get("instanceId") != agent_id:
        return None
    if fields.get("name") not in LEGACY_APP_NAMES:
        return None
    return fields


def load_matching_state(agent_id: str, user_id: str, state_path: Path = STATE) -> dict[str, Any] | None:
    try:
        data = json.loads(state_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if data.get("agent_id") != agent_id or data.get("agent_user_id") != user_id:
        return None
    app_id = str(data.get("app_id") or "")
    url = str(data.get("url") or "")
    match = URL_RE.fullmatch(url)
    if not match or match.group(1) != app_id or inspect_owned_app(app_id, agent_id) is None:
        return None
    return data


def save_state(data: dict[str, Any], state_path: Path = STATE) -> None:
    state_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(state_path.parent, 0o700)
    temporary = state_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    temporary.replace(state_path)


def wait_for_site(port: int, timeout: int = 90) -> None:
    deadline = time.monotonic() + timeout
    url = f"http://127.0.0.1:{port}/"
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as response:
                if 200 <= response.status < 500:
                    return
        except Exception:
            time.sleep(2)
    raise RuntimeError(f"Wanxiang site is not ready on port {port}")


async def clawchat_tools() -> Any:
    sys.path.insert(0, str(PLUGIN))
    from clawchat_gateway import tools

    return tools


async def register_once(port: int = DEFAULT_PORT) -> dict[str, Any]:
    if not ROOT.joinpath("package.json").is_file() or not LIVEWARE.is_file():
        raise RuntimeError("fixed Wanxiang Liveware installation is incomplete")
    agent_id, user_id = load_identity()
    wait_for_site(port)
    tools = await clawchat_tools()
    login = await tools.liveware_login()
    if isinstance(login, dict) and login.get("ok") is False:
        raise RuntimeError(str(login.get("error") or "Liveware login failed"))

    registered = await tools.list_apps()
    apps = registered.get("apps") if isinstance(registered, dict) else []
    apps = apps if isinstance(apps, list) else []
    state = load_matching_state(agent_id, user_id)
    app_id = str(state.get("app_id")) if state else ""

    if not app_id:
        for item in apps:
            if not isinstance(item, dict) or item.get("name") not in LEGACY_APP_NAMES:
                continue
            candidate = str(item.get("app_id") or "")
            if inspect_owned_app(candidate, agent_id) is not None:
                app_id = candidate
                break

    if not app_id:
        created = parse_fields(run_liveware("app", "create", APP_NAME, "--agent-type", "hermes"))
        app_id = str(created.get("appId") or "")
        if inspect_owned_app(app_id, agent_id) is None:
            raise RuntimeError("new Liveware app is not bound to the current Agent instance")

    url = app_url(app_id)
    run_liveware("tunnel", "bind", app_id, f"http://127.0.0.1:{port}")
    await tools.register_app(APP_NAME, app_id, url)

    for item in apps:
        if not isinstance(item, dict) or item.get("name") not in LEGACY_APP_NAMES:
            continue
        stale = str(item.get("app_id") or "")
        if stale and stale != app_id:
            await tools.unregister_app(stale)

    state = {
        "schemaVersion": 1,
        "agent_id": agent_id,
        "agent_user_id": user_id,
        "app_id": app_id,
        "app_name": APP_NAME,
        "url": url,
        "port": port,
    }
    save_state(state)
    return state


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--retry-seconds", type=int, default=15)
    parser.add_argument("--max-attempts", type=int, default=20)
    args = parser.parse_args()
    for attempt in range(1, max(1, args.max_attempts) + 1):
        try:
            state = asyncio.run(register_once(args.port))
            print(json.dumps({"status": "registered", "app_id": state["app_id"], "url": state["url"]}), flush=True)
            return 0
        except Exception as exc:
            print(f"registration attempt {attempt} failed: {exc}", file=sys.stderr, flush=True)
            if attempt < args.max_attempts:
                time.sleep(max(1, args.retry_seconds))
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
