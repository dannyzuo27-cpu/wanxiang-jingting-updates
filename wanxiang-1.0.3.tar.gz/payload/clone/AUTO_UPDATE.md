# 万象镜厅自动更新

自动更新完全由本地脚本完成，不调用模型。

## 克隆体侧

每个克隆体在 `/opt/data/wanxiang-update/config.json` 保存自己的更新设置。该文件属于本地私有配置，不进入更新包：

```json
{
  "feed_url": "https://你的更新仓库/stable.json",
  "channel": "stable",
  "auto_update": true,
  "interval_seconds": 86400
}
```

`ops/wanxiang_updater.py --daemon` 默认每 24 小时检查一次。它先验证创建者签名，再验证压缩包哈希和每个文件的哈希，只允许更新清单中的公共路径。安装前自动备份；构建、自检或启动失败时恢复旧文件。克隆者也可以把间隔改为 48 小时，但不得低于 15 分钟。

脚本禁止更新 Agent 身份、主人资料、认证、好友、聊天、记忆、运行数据库、私有配置、头像、每个克隆体自己的 Liveware 注册与地址。

Liveware 公共代码固定安装在 `/opt/data/workspace/wanxiang-jingting-site`。每次实例启动时，`wanxiang_liveware_register.py` 都会用当前 Agent 身份重新登录 Liveware，校验应用的 `instanceId`，绑定本地3100端口并重新注册卡片。实例独有的 `app_id`、Agent UID 和 URL 只保存在权限为 `0600` 的 `/opt/data/wanxiang-liveware/registration.json`，不进入更新包。

## 创建者发布侧

私钥只保存在创建者电脑，不得放进项目、Agent、克隆包或更新服务器。发布示例：

```sh
python3 scripts/build_update_release.py \
  --version 1.1.0 \
  --component liveware-content \
  --package-url https://你的更新仓库/wanxiang-1.1.0.tar.gz \
  --private-key /安全位置/wanxiang_update_signing_rsa.pem
```

可按需重复 `--component`：

- `liveware-content`：题目、计分、页面和六语界面；
- `agent-reading`：结果分析与隐私行为；
- `friend-welcome`：万象镜厅专用欢迎能力，包含两条独立触发链路（新克隆 Agent 向新主人首次欢迎，以及现有 Agent 向新好友欢迎）；
- `operations`：守护程序、更新器、每次启动的 Liveware 注册 Hook 与克隆规则。

上传生成的压缩包和 `stable.json` 即完成发布。没有被列入本次组件的能力不会改变。
